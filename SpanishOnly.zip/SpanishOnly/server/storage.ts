import { drizzle } from "drizzle-orm/neon-http";
import { neon } from "@neondatabase/serverless";
import { eq, desc, and, gte, lte, ilike, or } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import {
  users,
  products,
  orders,
  orderItems,
  loyaltyTokens,
  cartItems,
  categories,
  promotions,
  systemConfig,
  auditLog,
  type User,
  type InsertUser,
  type Product,
  type InsertProduct,
  type Order,
  type InsertOrder,
  type OrderItem,
  type LoyaltyToken,
  type CartItem,
  type Category,
  type InsertCategory,
  type Promotion,
  type SystemConfig,
  type AuditLog,
} from "@shared/schema";

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const sql = neon(process.env.DATABASE_URL);
const db = drizzle(sql);

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // Auth
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Products
  getProducts(limit?: number, offset?: number, categoryId?: string): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<boolean>;
  searchProducts(query: string): Promise<Product[]>;
  
  // Categories
  getCategories(): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Orders
  getOrders(limit?: number, offset?: number): Promise<Order[]>;
  getOrder(id: string): Promise<Order | undefined>;
  getOrderByCode(orderCode: string): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: string, status: string): Promise<Order | undefined>;
  getOrderItems(orderId: string): Promise<OrderItem[]>;
  createOrderItem(item: Omit<OrderItem, 'id'>): Promise<OrderItem>;
  
  // Loyalty Tokens
  getLoyaltyTokens(limit?: number, offset?: number): Promise<LoyaltyToken[]>;
  getLoyaltyToken(id: string): Promise<LoyaltyToken | undefined>;
  getLoyaltyTokenByCode(tokenCode: string): Promise<LoyaltyToken | undefined>;
  createLoyaltyToken(token: Omit<LoyaltyToken, 'id' | 'generatedAt'>): Promise<LoyaltyToken>;
  redeemLoyaltyToken(tokenCode: string): Promise<LoyaltyToken | undefined>;
  getActiveTokensByOrder(orderId: string): Promise<LoyaltyToken[]>;
  
  // Cart
  getCartItems(userId?: string, sessionId?: string): Promise<CartItem[]>;
  addCartItem(item: Omit<CartItem, 'id' | 'createdAt'>): Promise<CartItem>;
  updateCartItemQuantity(id: string, quantity: number): Promise<CartItem | undefined>;
  removeCartItem(id: string): Promise<boolean>;
  clearCart(userId?: string, sessionId?: string): Promise<boolean>;
  
  // Promotions
  getActivePromotions(): Promise<Promotion[]>;
  getPromotionByProduct(productId: string): Promise<Promotion | undefined>;
  
  // System Config
  getConfig(key: string): Promise<SystemConfig | undefined>;
  setConfig(key: string, value: string, description?: string): Promise<SystemConfig>;
  
  // Audit
  logAction(action: string, entity: string, entityId?: string, userId?: string, details?: any): Promise<AuditLog>;
  
  sessionStore: session.SessionStore;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.SessionStore;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      conString: process.env.DATABASE_URL,
      createTableIfMissing: true,
    });
  }

  // Auth methods
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  // Products methods
  async getProducts(limit = 20, offset = 0, categoryId?: string): Promise<Product[]> {
    let query = db.select().from(products).where(eq(products.isActive, true));
    
    if (categoryId) {
      query = query.where(and(eq(products.isActive, true), eq(products.categoryId, categoryId)));
    }
    
    return await query.limit(limit).offset(offset).orderBy(desc(products.createdAt));
  }

  async getProduct(id: string): Promise<Product | undefined> {
    const result = await db.select().from(products).where(eq(products.id, id)).limit(1);
    return result[0];
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const result = await db.insert(products).values(product).returning();
    return result[0];
  }

  async updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product | undefined> {
    const result = await db.update(products).set(product).where(eq(products.id, id)).returning();
    return result[0];
  }

  async deleteProduct(id: string): Promise<boolean> {
    const result = await db.update(products).set({ isActive: false }).where(eq(products.id, id));
    return result.rowCount > 0;
  }

  async searchProducts(query: string): Promise<Product[]> {
    return await db.select().from(products)
      .where(and(
        eq(products.isActive, true),
        or(
          ilike(products.name, `%${query}%`),
          ilike(products.description, `%${query}%`)
        )
      ))
      .limit(20);
  }

  // Categories methods
  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories).where(eq(categories.isActive, true));
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const result = await db.insert(categories).values(category).returning();
    return result[0];
  }

  // Orders methods
  async getOrders(limit = 20, offset = 0): Promise<Order[]> {
    return await db.select().from(orders).limit(limit).offset(offset).orderBy(desc(orders.createdAt));
  }

  async getOrder(id: string): Promise<Order | undefined> {
    const result = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
    return result[0];
  }

  async getOrderByCode(orderCode: string): Promise<Order | undefined> {
    const result = await db.select().from(orders).where(eq(orders.orderCode, orderCode)).limit(1);
    return result[0];
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const orderCode = `KIVO-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substr(2, 5).toUpperCase()}`;
    const result = await db.insert(orders).values({ ...order, orderCode }).returning();
    return result[0];
  }

  async updateOrderStatus(id: string, status: string): Promise<Order | undefined> {
    const result = await db.update(orders).set({ status }).where(eq(orders.id, id)).returning();
    return result[0];
  }

  async getOrderItems(orderId: string): Promise<OrderItem[]> {
    return await db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
  }

  async createOrderItem(item: Omit<OrderItem, 'id'>): Promise<OrderItem> {
    const result = await db.insert(orderItems).values(item).returning();
    return result[0];
  }

  // Loyalty Tokens methods
  async getLoyaltyTokens(limit = 20, offset = 0): Promise<LoyaltyToken[]> {
    return await db.select().from(loyaltyTokens).limit(limit).offset(offset).orderBy(desc(loyaltyTokens.generatedAt));
  }

  async getLoyaltyToken(id: string): Promise<LoyaltyToken | undefined> {
    const result = await db.select().from(loyaltyTokens).where(eq(loyaltyTokens.id, id)).limit(1);
    return result[0];
  }

  async getLoyaltyTokenByCode(tokenCode: string): Promise<LoyaltyToken | undefined> {
    const result = await db.select().from(loyaltyTokens).where(eq(loyaltyTokens.tokenCode, tokenCode)).limit(1);
    return result[0];
  }

  async createLoyaltyToken(token: Omit<LoyaltyToken, 'id' | 'generatedAt'>): Promise<LoyaltyToken> {
    const result = await db.insert(loyaltyTokens).values(token).returning();
    return result[0];
  }

  async redeemLoyaltyToken(tokenCode: string): Promise<LoyaltyToken | undefined> {
    const result = await db.update(loyaltyTokens)
      .set({ status: 'redeemed', redeemedAt: new Date() })
      .where(eq(loyaltyTokens.tokenCode, tokenCode))
      .returning();
    return result[0];
  }

  async getActiveTokensByOrder(orderId: string): Promise<LoyaltyToken[]> {
    return await db.select().from(loyaltyTokens)
      .where(and(
        eq(loyaltyTokens.orderId, orderId),
        eq(loyaltyTokens.status, 'active'),
        gte(loyaltyTokens.expiresAt, new Date())
      ));
  }

  // Cart methods
  async getCartItems(userId?: string, sessionId?: string): Promise<CartItem[]> {
    if (userId) {
      return await db.select().from(cartItems).where(eq(cartItems.userId, userId));
    } else if (sessionId) {
      return await db.select().from(cartItems).where(eq(cartItems.sessionId, sessionId));
    }
    return [];
  }

  async addCartItem(item: Omit<CartItem, 'id' | 'createdAt'>): Promise<CartItem> {
    const result = await db.insert(cartItems).values(item).returning();
    return result[0];
  }

  async updateCartItemQuantity(id: string, quantity: number): Promise<CartItem | undefined> {
    const result = await db.update(cartItems).set({ quantity }).where(eq(cartItems.id, id)).returning();
    return result[0];
  }

  async removeCartItem(id: string): Promise<boolean> {
    const result = await db.delete(cartItems).where(eq(cartItems.id, id));
    return result.rowCount > 0;
  }

  async clearCart(userId?: string, sessionId?: string): Promise<boolean> {
    if (userId) {
      const result = await db.delete(cartItems).where(eq(cartItems.userId, userId));
      return result.rowCount > 0;
    } else if (sessionId) {
      const result = await db.delete(cartItems).where(eq(cartItems.sessionId, sessionId));
      return result.rowCount > 0;
    }
    return false;
  }

  // Promotions methods
  async getActivePromotions(): Promise<Promotion[]> {
    const now = new Date();
    return await db.select().from(promotions)
      .where(and(
        eq(promotions.isActive, true),
        lte(promotions.startDate, now),
        gte(promotions.endDate, now)
      ));
  }

  async getPromotionByProduct(productId: string): Promise<Promotion | undefined> {
    const now = new Date();
    const result = await db.select().from(promotions)
      .where(and(
        eq(promotions.productId, productId),
        eq(promotions.isActive, true),
        lte(promotions.startDate, now),
        gte(promotions.endDate, now)
      ))
      .limit(1);
    return result[0];
  }

  // System Config methods
  async getConfig(key: string): Promise<SystemConfig | undefined> {
    const result = await db.select().from(systemConfig).where(eq(systemConfig.key, key)).limit(1);
    return result[0];
  }

  async setConfig(key: string, value: string, description?: string): Promise<SystemConfig> {
    const result = await db.insert(systemConfig)
      .values({ key, value, description })
      .onConflictDoUpdate({
        target: systemConfig.key,
        set: { value, description, updatedAt: new Date() }
      })
      .returning();
    return result[0];
  }

  // Audit methods
  async logAction(action: string, entity: string, entityId?: string, userId?: string, details?: any): Promise<AuditLog> {
    const result = await db.insert(auditLog).values({
      action,
      entity,
      entityId,
      userId,
      details
    }).returning();
    return result[0];
  }
}

export const storage = new DatabaseStorage();
