import type { Express } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import crypto from "crypto";
import QRCode from "qrcode";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { insertProductSchema, insertCategorySchema } from "@shared/schema";

export function registerRoutes(app: Express): Server {
  // Setup authentication routes
  setupAuth(app);

  // Products routes
  app.get("/api/products", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 20;
      const offset = parseInt(req.query.offset as string) || 0;
      const categoryId = req.query.categoryId as string;
      const search = req.query.search as string;

      let products;
      if (search) {
        products = await storage.searchProducts(search);
      } else {
        products = await storage.getProducts(limit, offset, categoryId);
      }

      // Get promotions for products
      const activePromotions = await storage.getActivePromotions();
      const productsWithPromotions = products.map(product => {
        const promotion = activePromotions.find(p => p.productId === product.id);
        return { ...product, promotion };
      });

      res.json(productsWithPromotions);
    } catch (error) {
      res.status(500).json({ message: "Error loading products" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }

      const promotion = await storage.getPromotionByProduct(product.id);
      res.json({ ...product, promotion });
    } catch (error) {
      res.status(500).json({ message: "Error loading product" });
    }
  });

  app.post("/api/products", async (req, res) => {
    if (!req.isAuthenticated() || !req.user?.isAdmin) {
      return res.status(401).json({ message: "Admin access required" });
    }

    try {
      const productData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(productData);
      
      await storage.logAction("create_product", "products", product.id, req.user.id, productData);
      res.status(201).json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid product data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating product" });
    }
  });

  app.put("/api/products/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user?.isAdmin) {
      return res.status(401).json({ message: "Admin access required" });
    }

    try {
      const productData = insertProductSchema.partial().parse(req.body);
      const product = await storage.updateProduct(req.params.id, productData);
      
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }

      await storage.logAction("update_product", "products", product.id, req.user.id, productData);
      res.json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid product data", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating product" });
    }
  });

  app.delete("/api/products/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user?.isAdmin) {
      return res.status(401).json({ message: "Admin access required" });
    }

    try {
      const success = await storage.deleteProduct(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Product not found" });
      }

      await storage.logAction("delete_product", "products", req.params.id, req.user.id);
      res.json({ message: "Product deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Error deleting product" });
    }
  });

  // Categories routes
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Error loading categories" });
    }
  });

  app.post("/api/categories", async (req, res) => {
    if (!req.isAuthenticated() || !req.user?.isAdmin) {
      return res.status(401).json({ message: "Admin access required" });
    }

    try {
      const categoryData = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory(categoryData);
      
      await storage.logAction("create_category", "categories", category.id, req.user.id, categoryData);
      res.status(201).json(category);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid category data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating category" });
    }
  });

  // Orders routes
  app.get("/api/orders", async (req, res) => {
    if (!req.isAuthenticated() || !req.user?.isAdmin) {
      return res.status(401).json({ message: "Admin access required" });
    }

    try {
      const limit = parseInt(req.query.limit as string) || 20;
      const offset = parseInt(req.query.offset as string) || 0;
      
      const orders = await storage.getOrders(limit, offset);
      
      // Get order items for each order
      const ordersWithItems = await Promise.all(
        orders.map(async (order) => {
          const items = await storage.getOrderItems(order.id);
          const tokens = await storage.getActiveTokensByOrder(order.id);
          return { ...order, items, tokens };
        })
      );

      res.json(ordersWithItems);
    } catch (error) {
      res.status(500).json({ message: "Error loading orders" });
    }
  });

  app.post("/api/orders", async (req, res) => {
    try {
      const orderSchema = z.object({
        customerName: z.string().min(1),
        customerEmail: z.string().email().optional(),
        customerPhone: z.string().optional(),
        items: z.array(z.object({
          productId: z.string(),
          quantity: z.number().min(1),
          price: z.string(),
        })).min(1),
        shippingAddress: z.object({
          street: z.string(),
          city: z.string(),
          state: z.string(),
          zipCode: z.string(),
        }).optional(),
        notes: z.string().optional(),
      });

      const orderData = orderSchema.parse(req.body);
      
      // Calculate totals
      const subtotal = orderData.items.reduce((sum, item) => 
        sum + (parseFloat(item.price) * item.quantity), 0
      );
      const shipping = 25; // Fixed shipping cost
      const total = subtotal + shipping;

      // Create order
      const order = await storage.createOrder({
        userId: req.user?.id,
        customerName: orderData.customerName,
        customerEmail: orderData.customerEmail,
        customerPhone: orderData.customerPhone,
        subtotal: subtotal.toString(),
        shipping: shipping.toString(),
        total: total.toString(),
        discount: "0",
        shippingAddress: orderData.shippingAddress,
        notes: orderData.notes,
      });

      // Create order items
      const orderItems = await Promise.all(
        orderData.items.map(item => 
          storage.createOrderItem({
            orderId: order.id,
            productId: item.productId,
            quantity: item.quantity,
            price: item.price,
            total: (parseFloat(item.price) * item.quantity).toString(),
          })
        )
      );

      await storage.logAction("create_order", "orders", order.id, req.user?.id, { 
        order, 
        items: orderItems 
      });

      res.status(201).json({ ...order, items: orderItems });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid order data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating order" });
    }
  });

  app.put("/api/orders/:id/status", async (req, res) => {
    if (!req.isAuthenticated() || !req.user?.isAdmin) {
      return res.status(401).json({ message: "Admin access required" });
    }

    try {
      const { status } = z.object({ status: z.string() }).parse(req.body);
      
      const order = await storage.updateOrderStatus(req.params.id, status);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }

      await storage.logAction("update_order_status", "orders", order.id, req.user.id, { status });
      res.json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid status data", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating order status" });
    }
  });

  // Loyalty Tokens routes
  app.get("/api/tokens", async (req, res) => {
    if (!req.isAuthenticated() || !req.user?.isAdmin) {
      return res.status(401).json({ message: "Admin access required" });
    }

    try {
      const limit = parseInt(req.query.limit as string) || 20;
      const offset = parseInt(req.query.offset as string) || 0;
      
      const tokens = await storage.getLoyaltyTokens(limit, offset);
      res.json(tokens);
    } catch (error) {
      res.status(500).json({ message: "Error loading tokens" });
    }
  });

  app.post("/api/tokens/generate", async (req, res) => {
    if (!req.isAuthenticated() || !req.user?.isAdmin) {
      return res.status(401).json({ message: "Admin access required" });
    }

    try {
      const { orderId } = z.object({ orderId: z.string() }).parse(req.body);
      
      const order = await storage.getOrder(orderId);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }

      // Generate encrypted token
      const tokenCode = crypto
        .createHash('sha256')
        .update(`${order.orderCode}-${Date.now()}-${Math.random()}`)
        .digest('hex');

      // Create QR data
      const qrData = JSON.stringify({
        cod_ficha: tokenCode,
        cod_compra: order.orderCode
      });

      // Set expiration (30 days from now)
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 30);

      const token = await storage.createLoyaltyToken({
        orderId,
        tokenCode,
        qrData,
        expiresAt
      });

      // Generate QR code image
      const qrImage = await QRCode.toDataURL(qrData, {
        width: 150,
        margin: 1,
        color: { dark: '#000000', light: '#FFFFFF' }
      });

      await storage.logAction("generate_token", "loyalty_tokens", token.id, req.user.id, { orderId });

      res.status(201).json({ ...token, qrImage });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid token data", errors: error.errors });
      }
      res.status(500).json({ message: "Error generating token" });
    }
  });

  app.post("/api/tokens/redeem", async (req, res) => {
    try {
      const { orderCode } = z.object({ orderCode: z.string() }).parse(req.body);
      
      const order = await storage.getOrderByCode(orderCode);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }

      const activeTokens = await storage.getActiveTokensByOrder(order.id);
      if (activeTokens.length === 0) {
        return res.status(400).json({ message: "No active tokens found for this order" });
      }

      // Check if we have enough tokens to redeem (5 tokens = 10% discount)
      const minTokensForDiscount = 5;
      const discountPercentage = 10;
      
      if (activeTokens.length >= minTokensForDiscount) {
        // Redeem the required tokens
        for (let i = 0; i < minTokensForDiscount; i++) {
          await storage.redeemLoyaltyToken(activeTokens[i].tokenCode);
        }

        await storage.logAction("redeem_tokens", "loyalty_tokens", order.id, req.user?.id, { 
          tokensRedeemed: minTokensForDiscount,
          discountPercentage 
        });

        res.json({ 
          success: true, 
          tokensRedeemed: minTokensForDiscount,
          discountPercentage,
          remainingTokens: activeTokens.length - minTokensForDiscount
        });
      } else {
        res.json({
          success: false,
          availableTokens: activeTokens.length,
          requiredTokens: minTokensForDiscount,
          message: `Need ${minTokensForDiscount} tokens for discount, only ${activeTokens.length} available`
        });
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid redeem data", errors: error.errors });
      }
      res.status(500).json({ message: "Error redeeming tokens" });
    }
  });

  app.post("/api/tokens/validate-qr", async (req, res) => {
    if (!req.isAuthenticated() || !req.user?.isAdmin) {
      return res.status(401).json({ message: "Admin access required" });
    }

    try {
      const { qrData } = z.object({ qrData: z.string() }).parse(req.body);
      
      const parsedData = JSON.parse(qrData);
      const { cod_ficha, cod_compra } = parsedData;

      const token = await storage.getLoyaltyTokenByCode(cod_ficha);
      if (!token) {
        return res.status(404).json({ message: "Token not found" });
      }

      if (token.status !== 'active') {
        return res.status(400).json({ message: "Token is not active" });
      }

      if (new Date(token.expiresAt) < new Date()) {
        return res.status(400).json({ message: "Token has expired" });
      }

      const order = await storage.getOrder(token.orderId);
      if (!order || order.orderCode !== cod_compra) {
        return res.status(400).json({ message: "Invalid order code" });
      }

      // Redeem the token
      const redeemedToken = await storage.redeemLoyaltyToken(cod_ficha);

      await storage.logAction("validate_qr_token", "loyalty_tokens", token.id, req.user.id, { 
        tokenCode: cod_ficha,
        orderCode: cod_compra 
      });

      res.json({ 
        success: true, 
        token: redeemedToken,
        order,
        message: "Token successfully validated and redeemed"
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid QR data", errors: error.errors });
      }
      res.status(500).json({ message: "Error validating QR token" });
    }
  });

  // Cart routes
  app.get("/api/cart", async (req, res) => {
    try {
      const sessionId = req.query.sessionId as string;
      const cartItems = await storage.getCartItems(req.user?.id, sessionId);
      
      // Get product details for each cart item
      const cartWithProducts = await Promise.all(
        cartItems.map(async (item) => {
          const product = await storage.getProduct(item.productId);
          return { ...item, product };
        })
      );

      res.json(cartWithProducts);
    } catch (error) {
      res.status(500).json({ message: "Error loading cart" });
    }
  });

  app.post("/api/cart", async (req, res) => {
    try {
      const { productId, quantity, sessionId } = z.object({
        productId: z.string(),
        quantity: z.number().min(1),
        sessionId: z.string().optional(),
      }).parse(req.body);

      const cartItem = await storage.addCartItem({
        userId: req.user?.id,
        sessionId,
        productId,
        quantity,
      });

      res.status(201).json(cartItem);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid cart data", errors: error.errors });
      }
      res.status(500).json({ message: "Error adding to cart" });
    }
  });

  app.put("/api/cart/:id", async (req, res) => {
    try {
      const { quantity } = z.object({ quantity: z.number().min(1) }).parse(req.body);
      
      const cartItem = await storage.updateCartItemQuantity(req.params.id, quantity);
      if (!cartItem) {
        return res.status(404).json({ message: "Cart item not found" });
      }

      res.json(cartItem);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid quantity", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating cart item" });
    }
  });

  app.delete("/api/cart/:id", async (req, res) => {
    try {
      const success = await storage.removeCartItem(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Cart item not found" });
      }

      res.json({ message: "Item removed from cart" });
    } catch (error) {
      res.status(500).json({ message: "Error removing cart item" });
    }
  });

  app.delete("/api/cart", async (req, res) => {
    try {
      const sessionId = req.query.sessionId as string;
      await storage.clearCart(req.user?.id, sessionId);
      res.json({ message: "Cart cleared" });
    } catch (error) {
      res.status(500).json({ message: "Error clearing cart" });
    }
  });

  // System config routes
  app.get("/api/config/:key", async (req, res) => {
    if (!req.isAuthenticated() || !req.user?.isAdmin) {
      return res.status(401).json({ message: "Admin access required" });
    }

    try {
      const config = await storage.getConfig(req.params.key);
      if (!config) {
        return res.status(404).json({ message: "Config not found" });
      }
      res.json(config);
    } catch (error) {
      res.status(500).json({ message: "Error loading config" });
    }
  });

  app.post("/api/config", async (req, res) => {
    if (!req.isAuthenticated() || !req.user?.isAdmin) {
      return res.status(401).json({ message: "Admin access required" });
    }

    try {
      const { key, value, description } = z.object({
        key: z.string(),
        value: z.string(),
        description: z.string().optional(),
      }).parse(req.body);

      const config = await storage.setConfig(key, value, description);
      
      await storage.logAction("update_config", "system_config", key, req.user.id, { key, value, description });
      res.json(config);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid config data", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating config" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
