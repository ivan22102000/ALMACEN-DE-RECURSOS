import { storage } from '../storage';
import { qrService } from './qr-service';
import type { LoyaltyToken, Order } from '@shared/schema';

export interface TokenGenerationOptions {
  qrSize?: '18mm' | '25mm' | '40mm';
  expiryDays?: number;
  autoGenerate?: boolean;
}

export interface TokenRedemptionResult {
  success: boolean;
  tokensRedeemed?: number;
  discountPercentage?: number;
  remainingTokens?: number;
  availableTokens?: number;
  requiredTokens?: number;
  message?: string;
  discountAmount?: number;
}

export interface TokenStats {
  totalTokens: number;
  activeTokens: number;
  redeemedTokens: number;
  expiredTokens: number;
  todayGenerated: number;
  todayRedeemed: number;
  redemptionRate: number;
  averageRedemptionTime: number; // in days
}

export class TokenService {
  private static instance: TokenService;

  static getInstance(): TokenService {
    if (!TokenService.instance) {
      TokenService.instance = new TokenService();
    }
    return TokenService.instance;
  }

  /**
   * Generate loyalty token for an order
   */
  async generateToken(
    orderId: string,
    options: TokenGenerationOptions = {}
  ): Promise<LoyaltyToken & { qrImage?: string }> {
    try {
      // Get order details
      const order = await storage.getOrder(orderId);
      if (!order) {
        throw new Error('Order not found');
      }

      // Check if token already exists for this order
      const existingTokens = await storage.getActiveTokensByOrder(orderId);
      if (existingTokens.length > 0) {
        throw new Error('Token already exists for this order');
      }

      // Get system configuration
      const expiryDays = options.expiryDays || 30;
      const qrSize = options.qrSize || '18mm';

      // Generate QR code
      const qrResult = await qrService.generateBitcoinStyleQR(order.orderCode, {
        size: qrSize,
        style: 'bitcoin',
      });

      // Calculate expiry date
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + expiryDays);

      // Create token in database
      const token = await storage.createLoyaltyToken({
        orderId,
        tokenCode: qrResult.tokenCode,
        qrData: qrResult.qrData,
        status: 'active',
        expiresAt,
      });

      // Log token generation
      await storage.logAction(
        'token_generated',
        'loyalty_tokens',
        token.id,
        undefined,
        {
          orderId,
          orderCode: order.orderCode,
          tokenCode: qrResult.tokenCode,
          expiryDays,
          qrSize,
        }
      );

      return {
        ...token,
        qrImage: qrResult.qrImage,
      };
    } catch (error) {
      console.error('Token generation error:', error);
      throw new Error(error instanceof Error ? error.message : 'Failed to generate token');
    }
  }

  /**
   * Redeem tokens for discount
   */
  async redeemTokens(
    orderCode: string,
    userId?: string
  ): Promise<TokenRedemptionResult> {
    try {
      // Get order
      const order = await storage.getOrderByCode(orderCode);
      if (!order) {
        return {
          success: false,
          message: 'Pedido no encontrado',
        };
      }

      // Get active tokens for this order
      const activeTokens = await storage.getActiveTokensByOrder(order.id);
      
      if (activeTokens.length === 0) {
        return {
          success: false,
          availableTokens: 0,
          requiredTokens: await this.getRequiredTokensForDiscount(),
          message: 'No hay fichas activas para este pedido',
        };
      }

      // Get system configuration for redemption
      const requiredTokens = await this.getRequiredTokensForDiscount();
      const discountPercentage = await this.getDiscountPercentage();

      if (activeTokens.length < requiredTokens) {
        return {
          success: false,
          availableTokens: activeTokens.length,
          requiredTokens,
          message: `Necesitas ${requiredTokens} fichas para obtener descuento, solo tienes ${activeTokens.length} disponibles`,
        };
      }

      // Redeem the required number of tokens
      const tokensToRedeem = activeTokens.slice(0, requiredTokens);
      const redeemPromises = tokensToRedeem.map(token =>
        storage.redeemLoyaltyToken(token.tokenCode)
      );

      await Promise.all(redeemPromises);

      // Calculate discount amount
      const orderTotal = parseFloat(order.total);
      const discountAmount = (orderTotal * discountPercentage) / 100;

      // Log redemption
      await storage.logAction(
        'tokens_redeemed',
        'loyalty_tokens',
        order.id,
        userId,
        {
          orderCode,
          tokensRedeemed: requiredTokens,
          discountPercentage,
          discountAmount,
          remainingTokens: activeTokens.length - requiredTokens,
        }
      );

      return {
        success: true,
        tokensRedeemed: requiredTokens,
        discountPercentage,
        discountAmount,
        remainingTokens: activeTokens.length - requiredTokens,
        message: `¡Felicidades! Has canjeado ${requiredTokens} fichas por ${discountPercentage}% de descuento`,
      };
    } catch (error) {
      console.error('Token redemption error:', error);
      throw new Error('Error al canjear fichas');
    }
  }

  /**
   * Validate and redeem QR code
   */
  async validateAndRedeemQR(
    qrDataString: string,
    userId?: string
  ): Promise<{
    success: boolean;
    token?: LoyaltyToken;
    order?: Order;
    message?: string;
  }> {
    try {
      // Validate QR format
      const validation = qrService.validateQRData(qrDataString);
      if (!validation.valid || !validation.data) {
        return {
          success: false,
          message: validation.error || 'Código QR inválido',
        };
      }

      const { cod_ficha, cod_compra } = validation.data;

      // Get token
      const token = await storage.getLoyaltyTokenByCode(cod_ficha);
      if (!token) {
        return {
          success: false,
          message: 'Ficha no encontrada',
        };
      }

      // Check token status
      if (token.status !== 'active') {
        return {
          success: false,
          message: 'Esta ficha ya ha sido canjeada o está inactiva',
        };
      }

      // Check expiry
      if (new Date(token.expiresAt) < new Date()) {
        return {
          success: false,
          message: 'Esta ficha ha expirado',
        };
      }

      // Get order and verify
      const order = await storage.getOrder(token.orderId);
      if (!order || order.orderCode !== cod_compra) {
        return {
          success: false,
          message: 'Código de compra no válido',
        };
      }

      // Redeem the token
      const redeemedToken = await storage.redeemLoyaltyToken(cod_ficha);
      if (!redeemedToken) {
        return {
          success: false,
          message: 'Error al canjear la ficha',
        };
      }

      // Log QR redemption
      await storage.logAction(
        'qr_token_redeemed',
        'loyalty_tokens',
        token.id,
        userId,
        {
          tokenCode: cod_ficha,
          orderCode: cod_compra,
          method: 'qr_scan',
        }
      );

      return {
        success: true,
        token: redeemedToken,
        order,
        message: 'Ficha canjeada exitosamente',
      };
    } catch (error) {
      console.error('QR validation error:', error);
      throw new Error('Error al validar código QR');
    }
  }

  /**
   * Auto-generate tokens for delivered orders
   */
  async autoGenerateTokens(): Promise<{
    generated: number;
    errors: string[];
  }> {
    try {
      // Get orders marked as delivered without tokens
      const orders = await storage.getOrders(100); // Get recent orders
      const deliveredOrders = orders.filter(order => 
        order.status === 'delivered'
      );

      let generated = 0;
      const errors: string[] = [];

      for (const order of deliveredOrders) {
        try {
          // Check if token already exists
          const existingTokens = await storage.getActiveTokensByOrder(order.id);
          if (existingTokens.length === 0) {
            await this.generateToken(order.id, { autoGenerate: true });
            generated++;
          }
        } catch (error) {
          errors.push(`Failed to generate token for order ${order.orderCode}: ${error}`);
        }
      }

      // Log auto-generation
      await storage.logAction(
        'auto_generate_tokens',
        'loyalty_tokens',
        undefined,
        undefined,
        {
          totalDeliveredOrders: deliveredOrders.length,
          tokensGenerated: generated,
          errors: errors.length,
        }
      );

      return { generated, errors };
    } catch (error) {
      console.error('Auto-generation error:', error);
      throw new Error('Error en generación automática de fichas');
    }
  }

  /**
   * Clean up expired tokens
   */
  async cleanupExpiredTokens(): Promise<number> {
    try {
      const tokens = await storage.getLoyaltyTokens(1000);
      const now = new Date();
      let cleanedCount = 0;

      for (const token of tokens) {
        if (token.status === 'active' && new Date(token.expiresAt) < now) {
          // Update token status to expired (assuming we add this method to storage)
          // For now, we'll just count them
          cleanedCount++;
        }
      }

      // Log cleanup
      await storage.logAction(
        'tokens_cleanup',
        'loyalty_tokens',
        undefined,
        undefined,
        {
          expiredTokens: cleanedCount,
          totalChecked: tokens.length,
        }
      );

      return cleanedCount;
    } catch (error) {
      console.error('Token cleanup error:', error);
      throw new Error('Error en limpieza de fichas expiradas');
    }
  }

  /**
   * Get token statistics
   */
  async getTokenStatistics(): Promise<TokenStats> {
    try {
      const tokens = await storage.getLoyaltyTokens(1000);
      const now = new Date();
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const activeTokens = tokens.filter(t => t.status === 'active' && new Date(t.expiresAt) > now);
      const redeemedTokens = tokens.filter(t => t.status === 'redeemed');
      const expiredTokens = tokens.filter(t => 
        t.status === 'active' && new Date(t.expiresAt) <= now
      );

      const todayGenerated = tokens.filter(t => 
        new Date(t.generatedAt) >= today
      );

      const todayRedeemed = tokens.filter(t => 
        t.redeemedAt && new Date(t.redeemedAt) >= today
      );

      const redemptionRate = tokens.length > 0 
        ? (redeemedTokens.length / tokens.length) * 100 
        : 0;

      // Calculate average redemption time
      const redeemedWithTimes = redeemedTokens.filter(t => t.redeemedAt);
      const averageRedemptionTime = redeemedWithTimes.length > 0
        ? redeemedWithTimes.reduce((sum, token) => {
            const generated = new Date(token.generatedAt);
            const redeemed = new Date(token.redeemedAt!);
            const days = (redeemed.getTime() - generated.getTime()) / (1000 * 60 * 60 * 24);
            return sum + days;
          }, 0) / redeemedWithTimes.length
        : 0;

      return {
        totalTokens: tokens.length,
        activeTokens: activeTokens.length,
        redeemedTokens: redeemedTokens.length,
        expiredTokens: expiredTokens.length,
        todayGenerated: todayGenerated.length,
        todayRedeemed: todayRedeemed.length,
        redemptionRate,
        averageRedemptionTime,
      };
    } catch (error) {
      console.error('Token statistics error:', error);
      throw new Error('Error al obtener estadísticas de fichas');
    }
  }

  /**
   * Get system configuration values
   */
  private async getRequiredTokensForDiscount(): Promise<number> {
    try {
      const config = await storage.getConfig('tokens_for_discount');
      return config ? parseInt(config.value) : 5;
    } catch (error) {
      return 5; // Default value
    }
  }

  private async getDiscountPercentage(): Promise<number> {
    try {
      const config = await storage.getConfig('discount_percentage');
      return config ? parseInt(config.value) : 10;
    } catch (error) {
      return 10; // Default value
    }
  }

  private async getTokensPerPurchase(): Promise<number> {
    try {
      const config = await storage.getConfig('tokens_per_purchase');
      return config ? parseInt(config.value) : 1;
    } catch (error) {
      return 1; // Default value
    }
  }

  private async getTokenExpiryDays(): Promise<number> {
    try {
      const config = await storage.getConfig('token_expiry_days');
      return config ? parseInt(config.value) : 30;
    } catch (error) {
      return 30; // Default value
    }
  }
}

export const tokenService = TokenService.getInstance();
