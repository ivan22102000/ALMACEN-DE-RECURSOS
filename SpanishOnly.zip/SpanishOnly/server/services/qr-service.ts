import QRCode from 'qrcode';
import crypto from 'crypto';
import { storage } from '../storage';

export interface QRCodeData {
  cod_ficha: string;
  cod_compra: string;
}

export interface QRGenerationOptions {
  size?: '18mm' | '25mm' | '40mm';
  format?: 'png' | 'svg' | 'pdf';
  quality?: 'low' | 'medium' | 'high';
  includeLabel?: boolean;
  style?: 'bitcoin' | 'standard';
}

export interface QRGenerationResult {
  qrData: string;
  qrImage: string;
  tokenCode: string;
  format: string;
  size: string;
  timestamp: string;
}

export class QRService {
  private static instance: QRService;

  static getInstance(): QRService {
    if (!QRService.instance) {
      QRService.instance = new QRService();
    }
    return QRService.instance;
  }

  /**
   * Generate encrypted token code using SHA-256
   */
  generateTokenCode(orderCode: string, timestamp?: number): string {
    const time = timestamp || Date.now();
    const randomSalt = crypto.randomBytes(16).toString('hex');
    const data = `${orderCode}-${time}-${randomSalt}`;
    
    return crypto
      .createHash('sha256')
      .update(data)
      .digest('hex');
  }

  /**
   * Create QR data object
   */
  createQRData(tokenCode: string, orderCode: string): QRCodeData {
    return {
      cod_ficha: tokenCode,
      cod_compra: orderCode,
    };
  }

  /**
   * Get QR code dimensions based on size option
   */
  private getQRDimensions(size: string): { width: number; height: number } {
    const sizes = {
      '18mm': { width: 150, height: 150 }, // ~18mm at 150 DPI
      '25mm': { width: 210, height: 210 }, // ~25mm at 150 DPI
      '40mm': { width: 340, height: 340 }, // ~40mm at 150 DPI
    };
    
    return sizes[size as keyof typeof sizes] || sizes['18mm'];
  }

  /**
   * Get QR code generation options
   */
  private getQROptions(options: QRGenerationOptions) {
    const { width, height } = this.getQRDimensions(options.size || '18mm');
    
    const qualityMap = {
      low: 'L',
      medium: 'M',
      high: 'H',
    };

    return {
      width,
      height,
      margin: 1,
      color: {
        dark: '#000000', // Black QR code (Bitcoin style)
        light: '#FFFFFF', // White background
      },
      errorCorrectionLevel: qualityMap[options.quality || 'medium'] as 'L' | 'M' | 'Q' | 'H',
    };
  }

  /**
   * Generate QR code image
   */
  async generateQRImage(
    qrData: QRCodeData,
    options: QRGenerationOptions = {}
  ): Promise<string> {
    try {
      const dataString = JSON.stringify(qrData);
      const qrOptions = this.getQROptions(options);

      let qrImage: string;

      if (options.format === 'svg') {
        qrImage = await QRCode.toString(dataString, {
          ...qrOptions,
          type: 'svg',
        });
      } else {
        // Default to PNG
        qrImage = await QRCode.toDataURL(dataString, {
          ...qrOptions,
          type: 'image/png',
        });
      }

      return qrImage;
    } catch (error) {
      console.error('QR generation error:', error);
      throw new Error('Failed to generate QR code image');
    }
  }

  /**
   * Generate complete QR code with Bitcoin styling
   */
  async generateBitcoinStyleQR(
    orderCode: string,
    options: QRGenerationOptions = {}
  ): Promise<QRGenerationResult> {
    try {
      // Generate encrypted token
      const tokenCode = this.generateTokenCode(orderCode);
      
      // Create QR data
      const qrData = this.createQRData(tokenCode, orderCode);
      
      // Generate QR image
      const qrImage = await this.generateQRImage(qrData, {
        ...options,
        style: 'bitcoin',
      });

      const result: QRGenerationResult = {
        qrData: JSON.stringify(qrData),
        qrImage,
        tokenCode,
        format: options.format || 'png',
        size: options.size || '18mm',
        timestamp: new Date().toISOString(),
      };

      // Log QR generation
      await storage.logAction(
        'qr_generated',
        'loyalty_tokens',
        tokenCode,
        undefined,
        {
          orderCode,
          size: options.size || '18mm',
          format: options.format || 'png',
          style: 'bitcoin',
        }
      );

      return result;
    } catch (error) {
      console.error('Bitcoin QR generation error:', error);
      throw new Error('Failed to generate Bitcoin-style QR code');
    }
  }

  /**
   * Validate QR data format
   */
  validateQRData(qrDataString: string): { valid: boolean; data?: QRCodeData; error?: string } {
    try {
      const parsed = JSON.parse(qrDataString);
      
      if (!parsed.cod_ficha || !parsed.cod_compra) {
        return {
          valid: false,
          error: 'QR data must contain cod_ficha and cod_compra',
        };
      }

      // Validate token format (should be 64-character hex string)
      if (!/^[a-f0-9]{64}$/i.test(parsed.cod_ficha)) {
        return {
          valid: false,
          error: 'Invalid token format',
        };
      }

      // Validate order code format (should start with KIVO-)
      if (!parsed.cod_compra.startsWith('KIVO-')) {
        return {
          valid: false,
          error: 'Invalid order code format',
        };
      }

      return {
        valid: true,
        data: parsed as QRCodeData,
      };
    } catch (error) {
      return {
        valid: false,
        error: 'Invalid QR data format',
      };
    }
  }

  /**
   * Generate printable QR with violet border (Bitcoin style)
   */
  async generatePrintableQR(
    qrData: QRCodeData,
    options: QRGenerationOptions = {}
  ): Promise<string> {
    try {
      const baseQR = await this.generateQRImage(qrData, options);
      
      // For now, return the base QR
      // In a real implementation, you could add border styling here
      // or use a library like Canvas to add the violet gradient border
      
      return baseQR;
    } catch (error) {
      console.error('Printable QR generation error:', error);
      throw new Error('Failed to generate printable QR code');
    }
  }

  /**
   * Batch generate QR codes for multiple orders
   */
  async batchGenerateQRs(
    orderCodes: string[],
    options: QRGenerationOptions = {}
  ): Promise<QRGenerationResult[]> {
    try {
      const results = await Promise.all(
        orderCodes.map(orderCode => 
          this.generateBitcoinStyleQR(orderCode, options)
        )
      );

      await storage.logAction(
        'qr_batch_generated',
        'loyalty_tokens',
        undefined,
        undefined,
        {
          orderCodes,
          count: results.length,
          options,
        }
      );

      return results;
    } catch (error) {
      console.error('Batch QR generation error:', error);
      throw new Error('Failed to generate batch QR codes');
    }
  }

  /**
   * Verify QR code authenticity
   */
  async verifyQRAuthenticity(qrDataString: string): Promise<{
    valid: boolean;
    tokenExists: boolean;
    expired: boolean;
    redeemed: boolean;
    error?: string;
  }> {
    try {
      const validation = this.validateQRData(qrDataString);
      
      if (!validation.valid || !validation.data) {
        return {
          valid: false,
          tokenExists: false,
          expired: false,
          redeemed: false,
          error: validation.error,
        };
      }

      // Check if token exists in database
      const token = await storage.getLoyaltyTokenByCode(validation.data.cod_ficha);
      
      if (!token) {
        return {
          valid: true,
          tokenExists: false,
          expired: false,
          redeemed: false,
          error: 'Token not found in database',
        };
      }

      const now = new Date();
      const expired = new Date(token.expiresAt) < now;
      const redeemed = token.status === 'redeemed';

      return {
        valid: true,
        tokenExists: true,
        expired,
        redeemed,
      };
    } catch (error) {
      console.error('QR verification error:', error);
      return {
        valid: false,
        tokenExists: false,
        expired: false,
        redeemed: false,
        error: 'Verification failed',
      };
    }
  }

  /**
   * Get QR statistics
   */
  async getQRStatistics(): Promise<{
    totalGenerated: number;
    totalActive: number;
    totalRedeemed: number;
    totalExpired: number;
    generatedToday: number;
    redeemedToday: number;
  }> {
    try {
      const tokens = await storage.getLoyaltyTokens(1000); // Get large sample
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const stats = {
        totalGenerated: tokens.length,
        totalActive: tokens.filter(t => t.status === 'active').length,
        totalRedeemed: tokens.filter(t => t.status === 'redeemed').length,
        totalExpired: tokens.filter(t => t.status === 'expired').length,
        generatedToday: tokens.filter(t => 
          new Date(t.generatedAt) >= today
        ).length,
        redeemedToday: tokens.filter(t => 
          t.redeemedAt && new Date(t.redeemedAt) >= today
        ).length,
      };

      return stats;
    } catch (error) {
      console.error('QR statistics error:', error);
      throw new Error('Failed to get QR statistics');
    }
  }
}

export const qrService = QRService.getInstance();
