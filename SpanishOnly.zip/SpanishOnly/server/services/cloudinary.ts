import { v2 as cloudinary } from 'cloudinary';
import { storage } from '../storage';

// Configure Cloudinary
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME || process.env.CLOUDINARY_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

export interface CloudinaryUploadResult {
  public_id: string;
  url: string;
  secure_url: string;
  width: number;
  height: number;
  format: string;
  resource_type: string;
  bytes: number;
}

export interface ImageUploadOptions {
  folder?: string;
  quality?: string | number;
  width?: number;
  height?: number;
  crop?: string;
  format?: string;
}

export class CloudinaryService {
  private static instance: CloudinaryService;
  private readonly defaultFolder = 'kivo/productos';

  static getInstance(): CloudinaryService {
    if (!CloudinaryService.instance) {
      CloudinaryService.instance = new CloudinaryService();
    }
    return CloudinaryService.instance;
  }

  /**
   * Upload an image to Cloudinary
   */
  async uploadImage(
    imageBuffer: Buffer,
    options: ImageUploadOptions = {}
  ): Promise<CloudinaryUploadResult> {
    try {
      const uploadOptions = {
        folder: options.folder || this.defaultFolder,
        quality: options.quality || 'auto',
        format: options.format || 'auto',
        resource_type: 'image' as const,
        ...options,
      };

      const result = await cloudinary.uploader.upload(
        `data:image/jpeg;base64,${imageBuffer.toString('base64')}`,
        uploadOptions
      );

      // Log upload action
      await storage.logAction(
        'cloudinary_upload',
        'images',
        result.public_id,
        undefined,
        {
          url: result.secure_url,
          folder: uploadOptions.folder,
          bytes: result.bytes,
          format: result.format,
        }
      );

      return result as CloudinaryUploadResult;
    } catch (error) {
      console.error('Cloudinary upload error:', error);
      throw new Error('Failed to upload image to Cloudinary');
    }
  }

  /**
   * Upload image from URL
   */
  async uploadFromUrl(
    imageUrl: string,
    options: ImageUploadOptions = {}
  ): Promise<CloudinaryUploadResult> {
    try {
      const uploadOptions = {
        folder: options.folder || this.defaultFolder,
        quality: options.quality || 'auto',
        format: options.format || 'auto',
        resource_type: 'image' as const,
        ...options,
      };

      const result = await cloudinary.uploader.upload(imageUrl, uploadOptions);

      await storage.logAction(
        'cloudinary_upload_url',
        'images',
        result.public_id,
        undefined,
        {
          source_url: imageUrl,
          url: result.secure_url,
          folder: uploadOptions.folder,
          bytes: result.bytes,
        }
      );

      return result as CloudinaryUploadResult;
    } catch (error) {
      console.error('Cloudinary URL upload error:', error);
      throw new Error('Failed to upload image from URL to Cloudinary');
    }
  }

  /**
   * Delete an image from Cloudinary
   */
  async deleteImage(publicId: string): Promise<boolean> {
    try {
      const result = await cloudinary.uploader.destroy(publicId);
      
      await storage.logAction(
        'cloudinary_delete',
        'images',
        publicId,
        undefined,
        { result: result.result }
      );

      return result.result === 'ok';
    } catch (error) {
      console.error('Cloudinary delete error:', error);
      throw new Error('Failed to delete image from Cloudinary');
    }
  }

  /**
   * Get optimized image URL with transformations
   */
  getOptimizedUrl(
    publicId: string,
    options: {
      width?: number;
      height?: number;
      quality?: string | number;
      format?: string;
      crop?: string;
    } = {}
  ): string {
    try {
      return cloudinary.url(publicId, {
        quality: options.quality || 'auto',
        format: options.format || 'auto',
        width: options.width,
        height: options.height,
        crop: options.crop || 'fill',
        secure: true,
      });
    } catch (error) {
      console.error('Cloudinary URL generation error:', error);
      return '';
    }
  }

  /**
   * Generate multiple sizes for responsive images
   */
  getResponsiveUrls(publicId: string): {
    thumbnail: string;
    small: string;
    medium: string;
    large: string;
    original: string;
  } {
    return {
      thumbnail: this.getOptimizedUrl(publicId, { width: 150, height: 150, crop: 'fill' }),
      small: this.getOptimizedUrl(publicId, { width: 300, height: 300, crop: 'fill' }),
      medium: this.getOptimizedUrl(publicId, { width: 600, height: 400, crop: 'fill' }),
      large: this.getOptimizedUrl(publicId, { width: 1200, height: 800, crop: 'fill' }),
      original: this.getOptimizedUrl(publicId, { quality: 'auto', format: 'auto' }),
    };
  }

  /**
   * Validate image file
   */
  validateImageFile(file: {
    mimetype: string;
    size: number;
  }): { valid: boolean; error?: string } {
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    const maxSize = 5 * 1024 * 1024; // 5MB

    if (!allowedTypes.includes(file.mimetype)) {
      return {
        valid: false,
        error: 'Tipo de archivo no válido. Solo se permiten JPEG, PNG y WebP.',
      };
    }

    if (file.size > maxSize) {
      return {
        valid: false,
        error: 'El archivo es demasiado grande. Máximo 5MB permitido.',
      };
    }

    return { valid: true };
  }

  /**
   * Extract public ID from Cloudinary URL
   */
  extractPublicId(cloudinaryUrl: string): string | null {
    try {
      const regex = /\/v\d+\/(.+?)\.[^.]+$/;
      const match = cloudinaryUrl.match(regex);
      return match ? match[1] : null;
    } catch (error) {
      console.error('Error extracting public ID:', error);
      return null;
    }
  }

  /**
   * Check if URL is a Cloudinary URL
   */
  isCloudinaryUrl(url: string): boolean {
    return url.includes('cloudinary.com') || url.includes('res.cloudinary.com');
  }

  /**
   * Clean up old images (for maintenance)
   */
  async cleanupOldImages(olderThanDays: number = 90): Promise<number> {
    try {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - olderThanDays);

      // Get resources older than cutoff date
      const result = await cloudinary.api.resources({
        type: 'upload',
        prefix: this.defaultFolder,
        max_results: 500,
        resource_type: 'image',
      });

      let deletedCount = 0;
      const deletePromises = result.resources
        .filter((resource: any) => new Date(resource.created_at) < cutoffDate)
        .map(async (resource: any) => {
          try {
            await this.deleteImage(resource.public_id);
            deletedCount++;
          } catch (error) {
            console.error(`Failed to delete ${resource.public_id}:`, error);
          }
        });

      await Promise.all(deletePromises);

      await storage.logAction(
        'cloudinary_cleanup',
        'images',
        undefined,
        undefined,
        {
          olderThanDays,
          deletedCount,
          totalChecked: result.resources.length,
        }
      );

      return deletedCount;
    } catch (error) {
      console.error('Cloudinary cleanup error:', error);
      throw new Error('Failed to cleanup old images');
    }
  }
}

export const cloudinaryService = CloudinaryService.getInstance();
