# KIVO Store - E-commerce Platform with Loyalty Token System

## Overview

KIVO Store is a complete e-commerce platform built for Bolivia with a revolutionary loyalty system based on QR-coded "fichas" (tokens) that work like Bitcoin. The platform allows customers to purchase products, earn loyalty tokens, and redeem them for discounts using dynamic QR codes printed on labels.

The application is built as a full-stack TypeScript application using React for the frontend, Express.js for the backend, PostgreSQL with Drizzle ORM for data persistence, and integrates with Cloudinary for image storage. The platform features a comprehensive admin panel for managing products, orders, and the loyalty token system.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Components**: Radix UI primitives with shadcn/ui components for a consistent design system
- **Styling**: Tailwind CSS with custom violet (#6C63FF) and white (#FFFFFF) theme
- **State Management**: TanStack Query (React Query) for server state with custom hooks for data fetching
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation schemas
- **Authentication**: JWT-based authentication with protected routes

### Backend Architecture
- **Framework**: Express.js with TypeScript for the REST API
- **Authentication**: Passport.js with local strategy and session management
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Session Storage**: PostgreSQL-based session store using connect-pg-simple
- **Security**: bcrypt for password hashing, JWT tokens, and SHA-256 encryption for QR codes

### Database Design
- **Users**: Admin and customer accounts with role-based access control
- **Products**: Catalog with categories, pricing, stock management, and loyalty token rewards
- **Orders**: Complete order lifecycle with items, status tracking, and customer information
- **Loyalty Tokens**: QR-coded tokens with generation, redemption, and expiration tracking
- **Categories**: Product organization and filtering
- **System Configuration**: Dynamic application settings storage
- **Audit Logging**: Security and operational event tracking

### Core Features
- **E-commerce Functionality**: Product catalog, shopping cart, checkout process, and order management
- **Loyalty Token System**: Bitcoin-style tokens with QR code generation, scanning, and redemption
- **Admin Dashboard**: Comprehensive management interface for orders, inventory, tokens, and system settings
- **Responsive Design**: Mobile-first approach with adaptive layouts and touch-friendly interfaces
- **Security**: Role-based access, encrypted tokens, and audit trails

### QR Code System
- **Token Generation**: SHA-256 encrypted tokens with order correlation
- **QR Code Creation**: Dynamic QR generation with configurable sizes (18mm, 25mm, 40mm)
- **Scanning Interface**: Camera-based QR scanner for token redemption
- **Redemption Logic**: Automatic discount calculation and token lifecycle management

## External Dependencies

### Database and Storage
- **Neon PostgreSQL**: Serverless PostgreSQL database hosting
- **Cloudinary**: Image storage and delivery for product photos in `kivo/productos` folder

### Authentication and Security
- **Passport.js**: Authentication middleware with local strategy
- **bcrypt**: Password hashing and verification
- **crypto**: Built-in Node.js module for token encryption and QR code security

### UI and Components
- **Radix UI**: Headless component primitives for accessibility and functionality
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens
- **Lucide React**: Icon library for consistent iconography

### Development Tools
- **Drizzle Kit**: Database schema management and migrations
- **Zod**: TypeScript-first schema validation
- **React Hook Form**: Form state management and validation
- **date-fns**: Date manipulation and formatting utilities

### Image and QR Processing
- **QRCode**: QR code generation library for loyalty tokens
- **Cloudinary SDK**: Image upload, transformation, and delivery

### Build and Development
- **Vite**: Frontend build tool and development server
- **tsx**: TypeScript execution for development
- **esbuild**: JavaScript bundler for production builds