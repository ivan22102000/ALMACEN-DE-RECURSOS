import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, getQueryFn, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { SystemConfig } from "@shared/schema";

export function useSystemConfig(key: string) {
  return useQuery<SystemConfig>({
    queryKey: ["/api/config", key],
    queryFn: getQueryFn({ on401: "returnNull" }),
    enabled: !!key,
  });
}

export function useUpdateConfig() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (configData: { key: string; value: string; description?: string }) => {
      const res = await apiRequest("POST", "/api/config", configData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/config"] });
      toast({
        title: "Configuración guardada",
        description: "Los ajustes se guardaron correctamente",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo guardar la configuración",
        variant: "destructive",
      });
    },
  });
}
