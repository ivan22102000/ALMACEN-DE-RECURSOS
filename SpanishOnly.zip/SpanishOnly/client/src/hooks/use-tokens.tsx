import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, getQueryFn, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { LoyaltyToken } from "@shared/schema";

interface TokenWithQR extends LoyaltyToken {
  qrImage?: string;
}

export function useTokens(limit?: number, offset?: number) {
  return useQuery<TokenWithQR[]>({
    queryKey: ["/api/tokens", { limit, offset }],
    queryFn: getQueryFn({ on401: "throw" }),
  });
}

export function useToken(id: string) {
  return useQuery<TokenWithQR>({
    queryKey: ["/api/tokens", id],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!id,
  });
}

export function useGenerateToken() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (orderId: string) => {
      const res = await apiRequest("POST", "/api/tokens/generate", { orderId });
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/tokens"] });
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      toast({
        title: "Ficha generada",
        description: "La ficha QR se generó correctamente",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo generar la ficha",
        variant: "destructive",
      });
    },
  });
}

export function useRedeemToken() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (orderCode: string) => {
      const res = await apiRequest("POST", "/api/tokens/redeem", { orderCode });
      return await res.json();
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["/api/tokens"] });
      if (result.success) {
        toast({
          title: "¡Fichas canjeadas!",
          description: `Has canjeado ${result.tokensRedeemed} fichas por ${result.discountPercentage}% de descuento`,
        });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Error al canjear fichas",
        description: error.message || "No se pudieron canjear las fichas",
        variant: "destructive",
      });
    },
  });
}

export function useValidateQR() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (qrData: string) => {
      const res = await apiRequest("POST", "/api/tokens/validate-qr", { qrData });
      return await res.json();
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["/api/tokens"] });
      toast({
        title: "QR validado",
        description: result.message || "Token validado y canjeado correctamente",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error validando QR",
        description: error.message || "No se pudo validar el código QR",
        variant: "destructive",
      });
    },
  });
}
