import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import type { Product } from "@shared/schema";

interface ProductsResponse extends Product {
  promotion?: {
    discountPercentage: string;
    endDate: string;
  };
}

export function useProducts(limit?: number, offset?: number, categoryId?: string, search?: string) {
  return useQuery<ProductsResponse[]>({
    queryKey: ["/api/products", { limit, offset, categoryId, search }],
    queryFn: getQueryFn({ on401: "throw" }),
  });
}

export function useProduct(id: string) {
  return useQuery<ProductsResponse>({
    queryKey: ["/api/products", id],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!id,
  });
}
