import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, getQueryFn, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Order, OrderItem, LoyaltyToken } from "@shared/schema";

interface OrderWithDetails extends Order {
  items?: OrderItem[];
  tokens?: LoyaltyToken[];
}

export function useOrders(limit?: number, offset?: number) {
  return useQuery<OrderWithDetails[]>({
    queryKey: ["/api/orders", { limit, offset }],
    queryFn: getQueryFn({ on401: "throw" }),
  });
}

export function useOrder(id: string) {
  return useQuery<OrderWithDetails>({
    queryKey: ["/api/orders", id],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!id,
  });
}

export function useUpdateOrderStatus() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ orderId, status }: { orderId: string; status: string }) => {
      const res = await apiRequest("PUT", `/api/orders/${orderId}/status`, { status });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      toast({
        title: "Estado actualizado",
        description: "El estado del pedido se actualizó correctamente",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo actualizar el estado",
        variant: "destructive",
      });
    },
  });
}

export function useCreateOrder() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (orderData: any) => {
      const res = await apiRequest("POST", "/api/orders", orderData);
      return await res.json();
    },
    onSuccess: (order) => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      toast({
        title: "¡Pedido creado!",
        description: `Tu pedido ${order.orderCode} ha sido procesado correctamente`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error al crear pedido",
        description: error.message || "No se pudo crear el pedido",
        variant: "destructive",
      });
    },
  });
}
