import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Coins, ShoppingCart, Clock } from "lucide-react";
import { formatCurrency } from "@/lib/format-currency";
import { useCart } from "@/hooks/use-cart";
import { useToast } from "@/hooks/use-toast";
import type { Product } from "@shared/schema";

interface ProductCardProps {
  product: Product & { 
    promotion?: { 
      discountPercentage: string; 
      endDate: string 
    } 
  };
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addToCartMutation } = useCart();
  const { toast } = useToast();
  const [timeLeft, setTimeLeft] = useState("");

  const hasPromotion = product.promotion && new Date(product.promotion.endDate) > new Date();
  const discountedPrice = hasPromotion 
    ? parseFloat(product.price) * (1 - parseFloat(product.promotion.discountPercentage) / 100)
    : null;

  // Calculate promotion countdown
  useEffect(() => {
    if (!hasPromotion) return;

    const updateCountdown = () => {
      const now = new Date();
      const endDate = new Date(product.promotion!.endDate);
      const difference = endDate.getTime() - now.getTime();

      if (difference > 0) {
        const days = Math.floor(difference / (1000 * 60 * 60 * 24));
        const hours = Math.floor((difference / (1000 * 60 * 60)) % 24);
        setTimeLeft(`${days}d ${hours}h`);
      } else {
        setTimeLeft("Expirado");
      }
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 3600000); // Update every hour

    return () => clearInterval(interval);
  }, [hasPromotion, product.promotion]);

  const handleAddToCart = () => {
    addToCartMutation.mutate(
      { productId: product.id, quantity: 1 },
      {
        onSuccess: () => {
          toast({
            title: "Producto añadido",
            description: `${product.name} se añadió al carrito`,
          });
        },
        onError: (error) => {
          toast({
            title: "Error",
            description: "No se pudo añadir el producto al carrito",
            variant: "destructive",
          });
        },
      }
    );
  };

  return (
    <Card className="hover:shadow-xl transition-all hover:scale-105 fade-in" data-testid={`card-product-${product.id}`}>
      <div className="relative">
        <img 
          src={product.imageUrl || "https://via.placeholder.com/400x300?text=Sin+Imagen"} 
          alt={product.name}
          className="w-full h-48 object-cover rounded-t-lg"
          data-testid={`img-product-${product.id}`}
        />
        
        {/* Promotion Timer */}
        {hasPromotion && timeLeft && timeLeft !== "Expirado" && (
          <div className="absolute top-2 right-2 promo-timer" data-testid={`promo-timer-${product.id}`}>
            <Clock className="inline mr-1 h-3 w-3" />
            Oferta: {timeLeft}
          </div>
        )}
        
        {/* Tokens Badge */}
        <div className="absolute top-2 left-2 bitcoin-badge" data-testid={`tokens-badge-${product.id}`}>
          <Coins className="inline mr-1 h-3 w-3" />
          +{product.tokensReward} Fichas
        </div>
      </div>
      
      <CardContent className="p-4">
        <h3 className="font-semibold text-lg mb-2" data-testid={`text-product-name-${product.id}`}>
          {product.name}
        </h3>
        
        {product.description && (
          <p className="text-muted-foreground text-sm mb-3 line-clamp-2" data-testid={`text-product-description-${product.id}`}>
            {product.description}
          </p>
        )}
        
        <div className="flex items-center justify-between mb-3">
          <div>
            {hasPromotion && discountedPrice ? (
              <div className="space-y-1">
                <span className="text-lg font-bold text-destructive line-through" data-testid={`text-original-price-${product.id}`}>
                  {formatCurrency(parseFloat(product.price))}
                </span>
                <div className="text-xl font-bold gradient-text" data-testid={`text-discounted-price-${product.id}`}>
                  {formatCurrency(discountedPrice)}
                </div>
              </div>
            ) : (
              <span className="text-xl font-bold gradient-text" data-testid={`text-price-${product.id}`}>
                {formatCurrency(parseFloat(product.price))}
              </span>
            )}
          </div>
          
          <div className="text-sm text-muted-foreground">
            Stock: <span data-testid={`text-stock-${product.id}`}>{product.stock}</span>
          </div>
        </div>
        
        <Button 
          className="w-full gradient-bg text-white glow-effect scale-on-hover"
          onClick={handleAddToCart}
          disabled={addToCartMutation.isPending || product.stock === 0}
          data-testid={`button-add-to-cart-${product.id}`}
        >
          {addToCartMutation.isPending ? (
            "Añadiendo..."
          ) : product.stock === 0 ? (
            "Sin Stock"
          ) : (
            <>
              <ShoppingCart className="mr-2 h-4 w-4" />
              Añadir al Carrito
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}
