import { Link } from "wouter";
import { Coins, Facebook, Instagram, MessageCircle } from "lucide-react";

export default function Footer() {
  return (
    <footer className="gradient-bg text-white py-12" data-testid="footer">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">KIVO Store</h3>
            <p className="text-sm opacity-90 mb-4">
              Tu tienda online de confianza en Bolivia con el revolucionario sistema de fichas de fidelidad tipo Bitcoin.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-white hover:text-accent transition-colors" data-testid="link-facebook">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-white hover:text-accent transition-colors" data-testid="link-instagram">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-white hover:text-accent transition-colors" data-testid="link-whatsapp">
                <MessageCircle className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Tienda</h4>
            <ul className="space-y-2 text-sm opacity-90">
              <li>
                <Link href="/productos">
                  <a className="hover:text-accent transition-colors" data-testid="link-catalog">Catálogo</a>
                </Link>
              </li>
              <li>
                <Link href="/productos?ofertas=true">
                  <a className="hover:text-accent transition-colors" data-testid="link-offers">Ofertas</a>
                </Link>
              </li>
              <li>
                <Link href="/productos?nuevos=true">
                  <a className="hover:text-accent transition-colors" data-testid="link-new-products">Nuevos Productos</a>
                </Link>
              </li>
              <li>
                <a href="#" className="hover:text-accent transition-colors" data-testid="link-brands">Marcas</a>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">
              <Coins className="inline mr-2 h-4 w-4" />
              Fichas KIVO
            </h4>
            <ul className="space-y-2 text-sm opacity-90">
              <li>
                <a href="#" className="hover:text-accent transition-colors" data-testid="link-how-it-works">Cómo Funciona</a>
              </li>
              <li>
                <Link href="/canjear">
                  <a className="hover:text-accent transition-colors" data-testid="link-redeem-tokens">Canjear Fichas</a>
                </Link>
              </li>
              <li>
                <a href="#" className="hover:text-accent transition-colors" data-testid="link-faq">Preguntas Frecuentes</a>
              </li>
              <li>
                <a href="#" className="hover:text-accent transition-colors" data-testid="link-terms">Términos y Condiciones</a>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Soporte</h4>
            <ul className="space-y-2 text-sm opacity-90">
              <li>
                <a href="#" className="hover:text-accent transition-colors" data-testid="link-contact">Contacto</a>
              </li>
              <li>
                <a href="#" className="hover:text-accent transition-colors" data-testid="link-shipping">Envíos</a>
              </li>
              <li>
                <a href="#" className="hover:text-accent transition-colors" data-testid="link-returns">Devoluciones</a>
              </li>
              <li>
                <a href="#" className="hover:text-accent transition-colors" data-testid="link-warranty">Garantías</a>
              </li>
            </ul>
          </div>
        </div>
        
        <hr className="my-8 opacity-30" />
        
        <div className="text-center text-sm opacity-90">
          <p>&copy; 2024 KIVO Store. Todos los derechos reservados. Hecho con ❤️ en Bolivia.</p>
        </div>
      </div>
    </footer>
  );
}
