import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Coins, ShoppingCart, Menu, User, LogOut } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useCart } from "@/hooks/use-cart";

export default function Header() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const { data: cartItems = [] } = useCart();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const cartItemsCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const navigation = [
    { name: "Inicio", href: "/", icon: null },
    { name: "Productos", href: "/productos", icon: null },
    { name: "Canjear Fichas", href: "/canjear", icon: null },
    ...(user?.isAdmin ? [{ name: "Administración", href: "/admin", icon: null }] : []),
  ];

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="gradient-bg shadow-lg sticky top-0 z-50" data-testid="header">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center space-x-3 cursor-pointer" data-testid="logo">
              <div className="text-white text-2xl font-bold">
                <span className="bg-white text-transparent bg-clip-text gradient-text">KIVO</span>
                <span className="text-white ml-2">Store</span>
              </div>
              <div className="bitcoin-badge">
                <Coins className="inline mr-1 h-3 w-3" />
                Sistema de Fichas
              </div>
            </div>
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-6 text-white">
            {navigation.map((item) => (
              <Link key={item.name} href={item.href}>
                <a
                  className={`hover:text-accent transition-colors ${
                    location === item.href ? "text-accent font-semibold" : ""
                  }`}
                  data-testid={`nav-${item.name.toLowerCase().replace(" ", "-")}`}
                >
                  {item.name}
                </a>
              </Link>
            ))}
          </nav>

          {/* Right Side Actions */}
          <div className="flex items-center space-x-4">
            {/* Cart */}
            <Link href="/carrito">
              <Button variant="ghost" size="icon" className="relative text-white hover:text-accent hover:bg-white/10" data-testid="button-cart">
                <ShoppingCart className="h-5 w-5" />
                {cartItemsCount > 0 && (
                  <Badge className="absolute -top-2 -right-2 bg-accent text-accent-foreground h-5 w-5 text-xs flex items-center justify-center p-0">
                    {cartItemsCount}
                  </Badge>
                )}
              </Button>
            </Link>

            {/* User Menu */}
            {user ? (
              <div className="flex items-center space-x-2">
                <span className="text-white text-sm hidden sm:block">
                  Hola, {user.firstName || user.username}
                </span>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="text-white hover:text-accent hover:bg-white/10"
                  onClick={handleLogout}
                  data-testid="button-logout"
                >
                  <LogOut className="h-5 w-5" />
                </Button>
              </div>
            ) : (
              <Link href="/auth">
                <Button variant="ghost" size="icon" className="text-white hover:text-accent hover:bg-white/10" data-testid="button-login">
                  <User className="h-5 w-5" />
                </Button>
              </Link>
            )}

            {/* Mobile Menu */}
            <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden text-white" data-testid="button-mobile-menu">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                <nav className="flex flex-col space-y-4 mt-6">
                  {navigation.map((item) => (
                    <Link key={item.name} href={item.href}>
                      <a
                        className={`text-lg py-2 px-4 rounded transition-colors ${
                          location === item.href 
                            ? "bg-primary text-primary-foreground" 
                            : "hover:bg-muted"
                        }`}
                        onClick={() => setIsMenuOpen(false)}
                        data-testid={`mobile-nav-${item.name.toLowerCase().replace(" ", "-")}`}
                      >
                        {item.name}
                      </a>
                    </Link>
                  ))}
                  
                  <hr className="my-4" />
                  
                  {user ? (
                    <div className="space-y-4">
                      <div className="px-4">
                        <p className="text-sm text-muted-foreground">Conectado como:</p>
                        <p className="font-semibold">{user.firstName || user.username}</p>
                        <p className="text-sm text-muted-foreground">{user.email}</p>
                      </div>
                      <Button 
                        variant="outline" 
                        className="w-full"
                        onClick={() => {
                          handleLogout();
                          setIsMenuOpen(false);
                        }}
                        data-testid="button-mobile-logout"
                      >
                        <LogOut className="mr-2 h-4 w-4" />
                        Cerrar Sesión
                      </Button>
                    </div>
                  ) : (
                    <Link href="/auth">
                      <Button 
                        className="w-full gradient-bg text-white"
                        onClick={() => setIsMenuOpen(false)}
                        data-testid="button-mobile-login"
                      >
                        <User className="mr-2 h-4 w-4" />
                        Iniciar Sesión
                      </Button>
                    </Link>
                  )}
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
