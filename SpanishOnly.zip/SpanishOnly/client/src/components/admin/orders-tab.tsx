import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Eye, Edit, QrCode, Loader2, Download } from "lucide-react";
import { useOrders } from "@/hooks/use-orders";
import { useGenerateToken } from "@/hooks/use-tokens";
import { useUpdateOrderStatus } from "@/hooks/use-orders";
import { formatCurrency } from "@/lib/format-currency";
import { format } from "date-fns";
import { es } from "date-fns/locale";

const statusColors = {
  pending: "bg-yellow-100 text-yellow-800",
  processing: "bg-blue-100 text-blue-800",
  shipped: "bg-purple-100 text-purple-800",
  delivered: "bg-green-100 text-green-800",
  cancelled: "bg-red-100 text-red-800",
};

const statusLabels = {
  pending: "Pendiente",
  processing: "Procesando",
  shipped: "Enviado",
  delivered: "Entregado",
  cancelled: "Cancelado",
};

export default function OrdersTab() {
  const { data: orders = [], isLoading } = useOrders();
  const generateTokenMutation = useGenerateToken();
  const updateStatusMutation = useUpdateOrderStatus();
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null);
  const [selectedTokenOrder, setSelectedTokenOrder] = useState<any>(null);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const handleStatusChange = (orderId: string, status: string) => {
    updateStatusMutation.mutate({ orderId, status });
  };

  const handleGenerateToken = (order: any) => {
    setSelectedTokenOrder(order);
  };

  const confirmGenerateToken = () => {
    if (selectedTokenOrder) {
      generateTokenMutation.mutate(selectedTokenOrder.id);
      setSelectedTokenOrder(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Gestión de Pedidos</h3>
        <Badge variant="outline" data-testid="orders-count">
          {orders.length} pedidos totales
        </Badge>
      </div>

      {orders.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center">
            <p className="text-muted-foreground">No hay pedidos registrados</p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Historial de Pedidos</CardTitle>
          </CardHeader>
          <CardContent>
            {/* Desktop View */}
            <div className="hidden md:block">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Código</TableHead>
                    <TableHead>Fecha</TableHead>
                    <TableHead>Cliente</TableHead>
                    <TableHead>Total</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Fichas</TableHead>
                    <TableHead>Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orders.map((order) => (
                    <TableRow key={order.id}>
                      <TableCell className="font-mono text-sm" data-testid={`order-code-${order.id}`}>
                        {order.orderCode}
                      </TableCell>
                      <TableCell data-testid={`order-date-${order.id}`}>
                        {format(new Date(order.createdAt), "dd/MM/yyyy", { locale: es })}
                      </TableCell>
                      <TableCell data-testid={`order-customer-${order.id}`}>
                        {order.customerName}
                      </TableCell>
                      <TableCell className="font-semibold" data-testid={`order-total-${order.id}`}>
                        {formatCurrency(parseFloat(order.total))}
                      </TableCell>
                      <TableCell>
                        <Select
                          value={order.status}
                          onValueChange={(status) => handleStatusChange(order.id, status)}
                          disabled={updateStatusMutation.isPending}
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue>
                              <Badge 
                                className={statusColors[order.status as keyof typeof statusColors]}
                                data-testid={`order-status-${order.id}`}
                              >
                                {statusLabels[order.status as keyof typeof statusLabels]}
                              </Badge>
                            </SelectValue>
                          </SelectTrigger>
                          <SelectContent>
                            {Object.entries(statusLabels).map(([value, label]) => (
                              <SelectItem key={value} value={value}>
                                {label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        {order.tokens && order.tokens.length > 0 ? (
                          <Badge className="bg-green-100 text-green-800" data-testid={`order-tokens-status-${order.id}`}>
                            {order.tokens.length} generadas
                          </Badge>
                        ) : (
                          <Badge variant="outline" data-testid={`order-tokens-status-${order.id}`}>
                            Sin fichas
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setExpandedOrder(
                              expandedOrder === order.id ? null : order.id
                            )}
                            data-testid={`button-view-${order.id}`}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          {(!order.tokens || order.tokens.length === 0) && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleGenerateToken(order)}
                              disabled={generateTokenMutation.isPending}
                              data-testid={`button-generate-token-${order.id}`}
                            >
                              <QrCode className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            {/* Mobile View */}
            <div className="md:hidden space-y-4">
              {orders.map((order) => (
                <Card key={order.id} className="border">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <div className="font-mono text-sm font-semibold" data-testid={`mobile-order-code-${order.id}`}>
                        {order.orderCode}
                      </div>
                      <Badge className={statusColors[order.status as keyof typeof statusColors]}>
                        {statusLabels[order.status as keyof typeof statusLabels]}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground mb-2">
                      {format(new Date(order.createdAt), "dd/MM/yyyy", { locale: es })}
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="font-semibold" data-testid={`mobile-order-total-${order.id}`}>
                        {formatCurrency(parseFloat(order.total))}
                      </span>
                      <div className="space-x-2">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => setExpandedOrder(expandedOrder === order.id ? null : order.id)}
                          data-testid={`mobile-button-view-${order.id}`}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        {(!order.tokens || order.tokens.length === 0) && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleGenerateToken(order)}
                            disabled={generateTokenMutation.isPending}
                            data-testid={`mobile-button-generate-token-${order.id}`}
                          >
                            <QrCode className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Order Details Expansion */}
            {expandedOrder && (
              <Card className="mt-4 bg-muted/50">
                <CardContent className="p-4">
                  {(() => {
                    const order = orders.find(o => o.id === expandedOrder);
                    if (!order) return null;
                    
                    return (
                      <div className="space-y-4">
                        <h4 className="font-semibold">Detalles del Pedido {order.orderCode}</h4>
                        <div className="grid md:grid-cols-2 gap-4 text-sm">
                          <div>
                            <p><strong>Cliente:</strong> {order.customerName}</p>
                            <p><strong>Email:</strong> {order.customerEmail || "No proporcionado"}</p>
                            <p><strong>Teléfono:</strong> {order.customerPhone || "No proporcionado"}</p>
                            <p><strong>Estado de Pago:</strong> {order.paymentStatus || "Pendiente"}</p>
                          </div>
                          <div>
                            <p><strong>Subtotal:</strong> {formatCurrency(parseFloat(order.subtotal))}</p>
                            <p><strong>Envío:</strong> {formatCurrency(parseFloat(order.shipping))}</p>
                            <p><strong>Descuento:</strong> {formatCurrency(parseFloat(order.discount))}</p>
                            <p><strong>Total:</strong> {formatCurrency(parseFloat(order.total))}</p>
                          </div>
                        </div>
                        {order.shippingAddress && (
                          <div>
                            <h5 className="font-medium mb-1">Dirección de Entrega:</h5>
                            <p className="text-sm text-muted-foreground">
                              {typeof order.shippingAddress === 'object' ? 
                                `${order.shippingAddress.street}, ${order.shippingAddress.city}, ${order.shippingAddress.state}` :
                                order.shippingAddress
                              }
                            </p>
                          </div>
                        )}
                        {order.notes && (
                          <div>
                            <h5 className="font-medium mb-1">Notas:</h5>
                            <p className="text-sm text-muted-foreground">{order.notes}</p>
                          </div>
                        )}
                        {order.items && order.items.length > 0 && (
                          <div>
                            <h5 className="font-medium mb-2">Productos:</h5>
                            <div className="space-y-1 text-sm">
                              {order.items.map((item, index) => (
                                <div key={index} className="flex justify-between bg-white rounded p-2">
                                  <span>{item.quantity}x Producto ID: {item.productId}</span>
                                  <span>{formatCurrency(parseFloat(item.total))}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </CardContent>
              </Card>
            )}
          </CardContent>
        </Card>
      )}

      {/* Generate Token Confirmation Modal */}
      <Dialog open={!!selectedTokenOrder} onOpenChange={() => setSelectedTokenOrder(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="gradient-text">
              <QrCode className="inline mr-2 h-5 w-5" />
              Generar Ficha QR
            </DialogTitle>
            <DialogDescription>
              ¿Deseas generar una ficha QR para el pedido{" "}
              <span className="font-mono font-semibold">
                {selectedTokenOrder?.orderCode}
              </span>?
            </DialogDescription>
          </DialogHeader>
          <div className="flex space-x-4">
            <Button 
              className="flex-1 gradient-bg text-white glow-effect"
              onClick={confirmGenerateToken}
              disabled={generateTokenMutation.isPending}
              data-testid="button-confirm-generate-token"
            >
              {generateTokenMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generando...
                </>
              ) : (
                <>
                  <QrCode className="mr-2 h-4 w-4" />
                  Generar Ficha
                </>
              )}
            </Button>
            <Button 
              variant="outline"
              className="flex-1"
              onClick={() => setSelectedTokenOrder(null)}
              data-testid="button-cancel-generate-token"
            >
              Cancelar
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
