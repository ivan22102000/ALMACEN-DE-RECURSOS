import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { QrCode, Download, Loader2, Eye, Search, Filter } from "lucide-react";
import { useTokens } from "@/hooks/use-tokens";
import { format } from "date-fns";
import { es } from "date-fns/locale";

const statusColors = {
  active: "bg-green-100 text-green-800",
  redeemed: "bg-blue-100 text-blue-800",
  expired: "bg-red-100 text-red-800",
};

const statusLabels = {
  active: "Activo",
  redeemed: "Canjeado",
  expired: "Expirado",
};

export default function TokensTab() {
  const { data: tokens = [], isLoading } = useTokens();
  const [selectedToken, setSelectedToken] = useState<any>(null);
  const [searchFilter, setSearchFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  // Filter tokens based on search and status
  const filteredTokens = tokens.filter(token => {
    const matchesSearch = !searchFilter || 
      (token.qrData && token.qrData.toLowerCase().includes(searchFilter.toLowerCase()));
    const matchesStatus = !statusFilter || token.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const activeTokens = tokens.filter(token => token.status === 'active');
  const redeemedTokens = tokens.filter(token => token.status === 'redeemed');
  const expiredTokens = tokens.filter(token => token.status === 'expired');

  const getOrderCodeFromQR = (qrData: string): string => {
    try {
      const parsed = JSON.parse(qrData);
      return parsed.cod_compra || "N/A";
    } catch {
      return "N/A";
    }
  };

  const downloadQR = (token: any) => {
    if (token.qrImage) {
      const link = document.createElement('a');
      link.href = token.qrImage;
      link.download = `ficha_${getOrderCodeFromQR(token.qrData)}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Gestión de Fichas</h3>
        <div className="flex space-x-2">
          <Badge variant="outline" className="bg-green-50" data-testid="active-tokens-count">
            {activeTokens.length} activas
          </Badge>
          <Badge variant="outline" className="bg-blue-50" data-testid="redeemed-tokens-count">
            {redeemedTokens.length} canjeadas
          </Badge>
          <Badge variant="outline" className="bg-red-50" data-testid="expired-tokens-count">
            {expiredTokens.length} expiradas
          </Badge>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Filter className="mr-2 h-5 w-5" />
            Filtros
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="search-tokens">Buscar por Código de Compra</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="search-tokens"
                  placeholder="KIVO-ABC123"
                  value={searchFilter}
                  onChange={(e) => setSearchFilter(e.target.value)}
                  className="pl-10 font-mono"
                  data-testid="input-search-tokens"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="filter-status">Filtrar por Estado</Label>
              <select
                id="filter-status"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full px-3 py-2 border border-border rounded-md focus:ring-2 focus:ring-ring"
                data-testid="select-status-filter"
              >
                <option value="">Todos los estados</option>
                <option value="active">Activos</option>
                <option value="redeemed">Canjeados</option>
                <option value="expired">Expirados</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {filteredTokens.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center">
            <p className="text-muted-foreground">
              {tokens.length === 0 ? "No hay fichas registradas" : "No se encontraron fichas con los filtros aplicados"}
            </p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Historial de Fichas ({filteredTokens.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {/* Desktop View */}
            <div className="hidden md:block">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Código de Compra</TableHead>
                    <TableHead>Fecha Generación</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Expira</TableHead>
                    <TableHead>Canjeado</TableHead>
                    <TableHead>Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTokens.map((token) => (
                    <TableRow key={token.id}>
                      <TableCell className="font-mono text-sm" data-testid={`token-order-code-${token.id}`}>
                        {getOrderCodeFromQR(token.qrData)}
                      </TableCell>
                      <TableCell data-testid={`token-generated-${token.id}`}>
                        {format(new Date(token.generatedAt), "dd/MM/yyyy HH:mm", { locale: es })}
                      </TableCell>
                      <TableCell>
                        <Badge 
                          className={statusColors[token.status as keyof typeof statusColors]}
                          data-testid={`token-status-${token.id}`}
                        >
                          {statusLabels[token.status as keyof typeof statusLabels]}
                        </Badge>
                      </TableCell>
                      <TableCell data-testid={`token-expires-${token.id}`}>
                        {format(new Date(token.expiresAt), "dd/MM/yyyy", { locale: es })}
                      </TableCell>
                      <TableCell data-testid={`token-redeemed-${token.id}`}>
                        {token.redeemedAt 
                          ? format(new Date(token.redeemedAt), "dd/MM/yyyy HH:mm", { locale: es })
                          : "-"
                        }
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setSelectedToken(token)}
                                data-testid={`button-view-qr-${token.id}`}
                              >
                                <QrCode className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-md">
                              <DialogHeader>
                                <DialogTitle className="gradient-text">
                                  Código QR de Ficha
                                </DialogTitle>
                              </DialogHeader>
                              <div className="text-center space-y-4">
                                <div className="qr-style w-48 h-48 mx-auto flex items-center justify-center">
                                  {token.qrImage ? (
                                    <img 
                                      src={token.qrImage} 
                                      alt="QR Code"
                                      className="w-full h-full object-contain"
                                      data-testid={`qr-image-${token.id}`}
                                    />
                                  ) : (
                                    <QrCode className="h-24 w-24 text-muted-foreground" />
                                  )}
                                </div>
                                <div className="text-sm space-y-1">
                                  <p><strong>Código:</strong> {getOrderCodeFromQR(token.qrData)}</p>
                                  <p><strong>Token:</strong> {token.tokenCode.substring(0, 16)}...</p>
                                  <p><strong>Estado:</strong> {statusLabels[token.status as keyof typeof statusLabels]}</p>
                                  <p><strong>Expira:</strong> {format(new Date(token.expiresAt), "dd/MM/yyyy", { locale: es })}</p>
                                </div>
                                <Button 
                                  variant="outline" 
                                  className="w-full"
                                  onClick={() => downloadQR(token)}
                                  disabled={!token.qrImage}
                                  data-testid={`button-download-qr-${token.id}`}
                                >
                                  <Download className="mr-2 h-4 w-4" />
                                  Descargar QR
                                </Button>
                              </div>
                            </DialogContent>
                          </Dialog>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedToken(token)}
                            data-testid={`button-view-details-${token.id}`}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            {/* Mobile View */}
            <div className="md:hidden space-y-4">
              {filteredTokens.map((token) => (
                <Card key={token.id} className="border">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <div className="font-mono text-sm font-semibold">
                        {getOrderCodeFromQR(token.qrData)}
                      </div>
                      <Badge className={statusColors[token.status as keyof typeof statusColors]}>
                        {statusLabels[token.status as keyof typeof statusLabels]}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground mb-2">
                      {format(new Date(token.generatedAt), "dd/MM/yyyy", { locale: es })}
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">
                        Expira: {format(new Date(token.expiresAt), "dd/MM/yyyy", { locale: es })}
                      </span>
                      <div className="space-x-2">
                        <Button variant="outline" size="sm">
                          <QrCode className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
