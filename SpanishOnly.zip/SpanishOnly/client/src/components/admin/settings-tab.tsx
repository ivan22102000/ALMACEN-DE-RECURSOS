import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Settings, Save, Coins, QrCode, Clock, AlertCircle, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useUpdateConfig } from "@/hooks/use-system-config";

const defaultConfigs = {
  tokens_per_purchase: "1",
  tokens_for_discount: "5",
  discount_percentage: "10",
  token_expiry_days: "30",
  qr_size: "18mm",
  auto_generate_tokens: "true",
  min_order_for_shipping: "200",
  shipping_cost: "25",
};

export default function SettingsTab() {
  const { toast } = useToast();
  const updateConfigMutation = useUpdateConfig();
  const [configs, setConfigs] = useState(defaultConfigs);
  const [isSaving, setIsSaving] = useState(false);

  const updateConfig = (key: keyof typeof configs, value: string) => {
    setConfigs(prev => ({ ...prev, [key]: value }));
  };

  const getConfigDescription = (key: string): string => {
    const descriptions: Record<string, string> = {
      tokens_per_purchase: "Cantidad de fichas otorgadas por cada compra",
      tokens_for_discount: "Fichas necesarias para obtener descuento",
      discount_percentage: "Porcentaje de descuento aplicado al canjear fichas",
      token_expiry_days: "Días hasta que expiren las fichas",
      qr_size: "Tamaño de códigos QR para impresión",
      auto_generate_tokens: "Generar fichas automáticamente al entregar pedidos",
      min_order_for_shipping: "Monto mínimo para envío gratuito",
      shipping_cost: "Costo de envío estándar",
    };
    return descriptions[key] || "";
  };

  const handleSaveAll = async () => {
    setIsSaving(true);
    const configEntries = Object.entries(configs);
    
    try {
      for (const [key, value] of configEntries) {
        await new Promise(resolve => {
          updateConfigMutation.mutate(
            {
              key,
              value,
              description: getConfigDescription(key),
            },
            {
              onSuccess: () => resolve(true),
              onError: () => resolve(false),
            }
          );
        });
      }
      
      toast({
        title: "¡Configuración guardada!",
        description: "Todos los ajustes se guardaron correctamente",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Algunos ajustes no se pudieron guardar",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Configuración del Sistema</h3>
        <Button 
          className="gradient-bg text-white glow-effect"
          onClick={handleSaveAll}
          disabled={isSaving || updateConfigMutation.isPending}
          data-testid="button-save-all"
        >
          {isSaving ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Guardando...
            </>
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" />
              Guardar Todo
            </>
          )}
        </Button>
      </div>

      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          Los cambios en la configuración afectarán el comportamiento del sistema inmediatamente.
          Asegúrate de revisar todos los valores antes de guardar.
        </AlertDescription>
      </Alert>

      <div className="grid gap-6">
        {/* Token System Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Coins className="mr-2 h-5 w-5" />
              Sistema de Fichas
            </CardTitle>
            <CardDescription>
              Configuración del sistema de fidelidad y recompensas tipo Bitcoin
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="tokens-per-purchase">Fichas por Compra</Label>
                <Input
                  id="tokens-per-purchase"
                  type="number"
                  min="1"
                  value={configs.tokens_per_purchase}
                  onChange={(e) => updateConfig("tokens_per_purchase", e.target.value)}
                  data-testid="input-tokens-per-purchase"
                />
                <p className="text-sm text-muted-foreground">
                  Cantidad de fichas que recibe el cliente por cada compra
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="tokens-for-discount">Fichas para Descuento</Label>
                <Input
                  id="tokens-for-discount"
                  type="number"
                  min="1"
                  value={configs.tokens_for_discount}
                  onChange={(e) => updateConfig("tokens_for_discount", e.target.value)}
                  data-testid="input-tokens-for-discount"
                />
                <p className="text-sm text-muted-foreground">
                  Fichas necesarias para obtener descuento
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="discount-percentage">Porcentaje de Descuento (%)</Label>
                <Input
                  id="discount-percentage"
                  type="number"
                  min="1"
                  max="100"
                  value={configs.discount_percentage}
                  onChange={(e) => updateConfig("discount_percentage", e.target.value)}
                  data-testid="input-discount-percentage"
                />
                <p className="text-sm text-muted-foreground">
                  Descuento aplicado al canjear las fichas requeridas
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="token-expiry">Días de Expiración</Label>
                <Input
                  id="token-expiry"
                  type="number"
                  min="1"
                  value={configs.token_expiry_days}
                  onChange={(e) => updateConfig("token_expiry_days", e.target.value)}
                  data-testid="input-token-expiry"
                />
                <p className="text-sm text-muted-foreground">
                  Días hasta que expiren las fichas desde su generación
                </p>
              </div>
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Generación Automática de Fichas</Label>
                <p className="text-sm text-muted-foreground">
                  Generar fichas automáticamente cuando un pedido se marca como "entregado"
                </p>
              </div>
              <Switch
                checked={configs.auto_generate_tokens === "true"}
                onCheckedChange={(checked) => 
                  updateConfig("auto_generate_tokens", checked ? "true" : "false")
                }
                data-testid="switch-auto-generate"
              />
            </div>
          </CardContent>
        </Card>

        {/* QR Code Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <QrCode className="mr-2 h-5 w-5" />
              Códigos QR
            </CardTitle>
            <CardDescription>
              Configuración de códigos QR para impresión en etiquetas
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="qr-size">Tamaño de QR</Label>
              <Select
                value={configs.qr_size}
                onValueChange={(value) => updateConfig("qr_size", value)}
              >
                <SelectTrigger data-testid="select-qr-size">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="18mm">18mm x 18mm (Estándar)</SelectItem>
                  <SelectItem value="25mm">25mm x 25mm (Mediano)</SelectItem>
                  <SelectItem value="40mm">40mm x 40mm (Grande)</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-sm text-muted-foreground">
                Tamaño para impresión en etiquetas (compatible con impresoras térmicas Brother/Zebra)
              </p>
            </div>

            <div className="bg-muted rounded-lg p-4">
              <h4 className="font-medium mb-2">Vista Previa del QR</h4>
              <div className="qr-style w-32 h-32 flex items-center justify-center">
                <QrCode className="h-16 w-16 text-muted-foreground" />
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Estilo Bitcoin: Fondo blanco, código negro, borde con gradiente negro-violeta
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Shipping Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Settings className="mr-2 h-5 w-5" />
              Configuración de Envíos
            </CardTitle>
            <CardDescription>
              Ajustes relacionados con costos y políticas de envío
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor# thoughts

Looking at the request, I need to create a complete KIVO Store application for Bolivia with a loyalty token system based on "Bitcoin-style" QR codes. The application should include:

1. A complete e-commerce frontend with gradient black to violet phosphorescent design
2. Product catalog with shopping cart functionality
3. Bitcoin-style loyalty token system with QR code generation
4. Admin panel for managing orders, tokens, inventory, and settings
5. Token redemption system (web and QR scanner for admins)
6. Integration with Supabase, Cloudinary, and other services

The design reference shows a sophisticated gradient theme from black (#000000) to violet phosphorescent (#C084FC) with proper responsive design. I need to implement all the missing service files and ensure the application is production-ready.

Key missing components that need to be implemented:
- Cloudinary service for image uploads
- QR service for generating Bitcoin-style QR codes
- Token service for managing loyalty tokens
- Proper error handling and validation
- Complete Spanish translations throughout

# useful_guidelines_from_blueprints

From the authentication blueprint:
- Both registration and login forms must be present on the authentication page
- Follow the correct format as given in the reference index.css file for any customization
- Use proper session management and authentication flow
- Redirect authenticated users appropriately

From the general guidelines:
- Use `wouter` for routing on the frontend
- Always use `@tanstack/react-query` when fetching data
- Use shadcn's `useForm` hook and `Form` component for forms
- Add `data-testid` attributes to interactive elements
- Keep backend routes thin and use storage interface for CRUD operations
- Validate request bodies using Zod schemas

# directory_structure

```json
[
    {"path": "server/services/cloudinary.ts", "status": "new"},
    {"path": "server/services/qr-service.ts", "status": "new"},
    {"path": "server/services/token-service.ts", "status": "new"}
]
