import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ShoppingCart, Coins, Package, Settings } from "lucide-react";
import OrdersTab from "./orders-tab";
import TokensTab from "./tokens-tab";
import InventoryTab from "./inventory-tab";
import SettingsTab from "./settings-tab";

interface AdminTabsProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export default function AdminTabs({ activeTab, onTabChange }: AdminTabsProps) {
  return (
    <Tabs value={activeTab} onValueChange={onTabChange}>
      <TabsList className="grid w-full grid-cols-4">
        <TabsTrigger value="pedidos" data-testid="tab-orders">
          <ShoppingCart className="mr-2 h-4 w-4" />
          Pedidos
        </TabsTrigger>
        <TabsTrigger value="fichas" data-testid="tab-tokens">
          <Coins className="mr-2 h-4 w-4" />
          Fichas
        </TabsTrigger>
        <TabsTrigger value="inventario" data-testid="tab-inventory">
          <Package className="mr-2 h-4 w-4" />
          Inventario
        </TabsTrigger>
        <TabsTrigger value="ajustes" data-testid="tab-settings">
          <Settings className="mr-2 h-4 w-4" />
          Ajustes
        </TabsTrigger>
      </TabsList>

      <TabsContent value="pedidos" className="mt-6">
        <OrdersTab />
      </TabsContent>

      <TabsContent value="fichas" className="mt-6">
        <TokensTab />
      </TabsContent>

      <TabsContent value="inventario" className="mt-6">
        <InventoryTab />
      </TabsContent>

      <TabsContent value="ajustes" className="mt-6">
        <SettingsTab />
      </TabsContent>
    </Tabs>
  );
}
