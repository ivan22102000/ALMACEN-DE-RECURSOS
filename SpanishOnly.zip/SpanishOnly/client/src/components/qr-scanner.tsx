import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Camera, CameraOff, AlertCircle } from "lucide-react";

interface QRScannerProps {
  onScan: (data: string) => void;
  onError: (error: string) => void;
}

export default function QRScanner({ onScan, onError }: QRScannerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scanIntervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    startCamera();
    return () => {
      stopScanning();
    };
  }, []);

  const startCamera = async () => {
    try {
      setError(null);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          facingMode: 'environment',
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.addEventListener('loadedmetadata', () => {
          if (videoRef.current) {
            videoRef.current.play();
            setIsScanning(true);
            startScanning();
          }
        });
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'No se pudo acceder a la cámara';
      setError(errorMessage);
      onError(errorMessage);
    }
  };

  const startScanning = () => {
    scanIntervalRef.current = setInterval(() => {
      scanQRCode();
    }, 500); // Scan every 500ms
  };

  const stopScanning = () => {
    if (scanIntervalRef.current) {
      clearInterval(scanIntervalRef.current);
      scanIntervalRef.current = null;
    }

    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
    }
    setIsScanning(false);
  };

  const scanQRCode = async () => {
    if (!videoRef.current || !canvasRef.current || !isScanning) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');

    if (!context || video.videoWidth === 0) return;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    try {
      // Try to use jsQR library if available
      if (typeof window !== 'undefined' && (window as any).jsQR) {
        const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
        const code = (window as any).jsQR(imageData.data, imageData.width, imageData.height);
        
        if (code) {
          stopScanning();
          onScan(code.data);
        }
      } else {
        // Fallback: try to use native BarcodeDetector if available
        if ('BarcodeDetector' in window) {
          const detector = new (window as any).BarcodeDetector({ formats: ['qr_code'] });
          const codes = await detector.detect(canvas);
          
          if (codes.length > 0) {
            stopScanning();
            onScan(codes[0].rawValue);
          }
        }
      }
    } catch (err) {
      // Silent error - scanning will continue
    }
  };

  const handleManualStop = () => {
    stopScanning();
  };

  return (
    <div className="space-y-4" data-testid="qr-scanner">
      {error ? (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            {error}. Asegúrate de permitir el acceso a la cámara.
          </AlertDescription>
        </Alert>
      ) : (
        <div className="relative">
          <video
            ref={videoRef}
            className="w-full h-64 bg-black rounded-lg object-cover"
            playsInline
            muted
            data-testid="video-scanner"
          />
          <canvas
            ref={canvasRef}
            className="hidden"
          />
          
          {/* Scanning overlay */}
          {isScanning && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-48 h-48 border-2 border-primary rounded-lg relative">
                <div className="absolute top-0 left-0 w-6 h-6 border-t-4 border-l-4 border-primary"></div>
                <div className="absolute top-0 right-0 w-6 h-6 border-t-4 border-r-4 border-primary"></div>
                <div className="absolute bottom-0 left-0 w-6 h-6 border-b-4 border-l-4 border-primary"></div>
                <div className="absolute bottom-0 right-0 w-6 h-6 border-b-4 border-r-4 border-primary"></div>
              </div>
            </div>
          )}
        </div>
      )}

      <div className="flex justify-center space-x-4">
        {isScanning ? (
          <Button 
            variant="outline" 
            onClick={handleManualStop}
            data-testid="button-stop-scanning"
          >
            <CameraOff className="mr-2 h-4 w-4" />
            Detener Escáner
          </Button>
        ) : (
          <Button 
            onClick={startCamera}
            className="gradient-bg text-white"
            data-testid="button-start-scanning"
          >
            <Camera className="mr-2 h-4 w-4" />
            Reiniciar Cámara
          </Button>
        )}
      </div>

      <p className="text-sm text-muted-foreground text-center">
        Enfoca el código QR de la ficha dentro del marco para escanear
      </p>

      {/* Load jsQR library */}
      <script src="https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.min.js" />
    </div>
  );
}
