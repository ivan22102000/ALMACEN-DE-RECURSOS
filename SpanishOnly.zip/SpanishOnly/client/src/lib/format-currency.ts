export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('es-BO', { 
    style: 'currency', 
    currency: 'BOB',
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function parseCurrency(value: string): number {
  return parseFloat(value.replace(/[^\d.-]/g, ''));
}
