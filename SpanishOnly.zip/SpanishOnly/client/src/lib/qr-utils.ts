export interface QRCodeData {
  cod_ficha: string;
  cod_compra: string;
}

export function parseQRData(qrDataString: string): QRCodeData | null {
  try {
    const parsed = JSON.parse(qrDataString);
    if (parsed.cod_ficha && parsed.cod_compra) {
      return parsed as QRCodeData;
    }
    return null;
  } catch (error) {
    console.error("Error parsing QR data:", error);
    return null;
  }
}

export function generateQRDataString(tokenCode: string, orderCode: string): string {
  return JSON.stringify({
    cod_ficha: tokenCode,
    cod_compra: orderCode,
  });
}

export function validateQRData(qrData: QRCodeData): boolean {
  return !!(qrData.cod_ficha && qrData.cod_compra);
}

export function getQRSize(sizeOption: string): { width: number; height: number } {
  const sizes = {
    "18mm": { width: 150, height: 150 },  // ~18mm at 150 DPI
    "25mm": { width: 210, height: 210 },  // ~25mm at 150 DPI
    "40mm": { width: 340, height: 340 },  // ~40mm at 150 DPI
  };
  
  return sizes[sizeOption as keyof typeof sizes] || sizes["18mm"];
}

export function generateQROptions(size: string = "18mm") {
  const { width, height } = getQRSize(size);
  
  return {
    width,
    height,
    margin: 1,
    color: {
      dark: '#000000',  // Black QR code
      light: '#FFFFFF', // White background
    },
    errorCorrectionLevel: 'M' as const,
  };
}

export function createPrintableQR(qrImageData: string, size: string = "18mm"): string {
  const { width, height } = getQRSize(size);
  
  // Create a canvas with the QR code and violet border
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  
  if (!ctx) return qrImageData;
  
  // Add border space
  const borderWidth = 4;
  canvas.width = width + (borderWidth * 2);
  canvas.height = height + (borderWidth * 2);
  
  // Fill white background
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  
  // Draw violet border (gradient from black to violet)
  const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
  gradient.addColorStop(0, '#000000');
  gradient.addColorStop(1, '#7C3AED');
  
  ctx.strokeStyle = gradient;
  ctx.lineWidth = borderWidth;
  ctx.strokeRect(borderWidth / 2, borderWidth / 2, width + borderWidth, height + borderWidth);
  
  // Load and draw the QR image
  const img = new Image();
  img.onload = () => {
    ctx.drawImage(img, borderWidth, borderWidth, width, height);
  };
  img.src = qrImageData;
  
  return canvas.toDataURL();
}
