import { useState } from "react";
import { Redirect } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, ShoppingCart, Coins, Package, Settings, BarChart3 } from "lucide-react";
import Header from "@/components/header";
import Footer from "@/components/footer";
import { useAuth } from "@/hooks/use-auth";
import { useOrders } from "@/hooks/use-orders";
import { useTokens } from "@/hooks/use-tokens";
import OrdersTab from "@/components/admin/orders-tab";
import TokensTab from "@/components/admin/tokens-tab";
import InventoryTab from "@/components/admin/inventory-tab";
import SettingsTab from "@/components/admin/settings-tab";

export default function AdminPage() {
  const { user, isLoading } = useAuth();
  const [activeTab, setActiveTab] = useState("pedidos");
  
  // Get statistics for dashboard
  const { data: orders = [] } = useOrders(50); // Get more orders for stats
  const { data: tokens = [] } = useTokens(50);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user?.isAdmin) {
    return <Redirect to="/auth" />;
  }

  // Calculate statistics
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const todayOrders = orders.filter(order => 
    new Date(order.createdAt) >= today
  );
  
  const todayTokens = tokens.filter(token => 
    new Date(token.generatedAt || token.createdAt) >= today
  );
  
  const redeemedTokens = tokens.filter(token => token.status === 'redeemed');
  
  const todaySales = todayOrders.reduce((sum, order) => 
    sum + parseFloat(order.total), 0
  );

  const stats = [
    {
      title: "Pedidos Hoy",
      value: todayOrders.length,
      icon: ShoppingCart,
      color: "text-blue-600",
    },
    {
      title: "Fichas Generadas",
      value: todayTokens.length,
      icon: Coins,
      color: "text-yellow-600",
    },
    {
      title: "Fichas Canjeadas",
      value: redeemedTokens.length,
      icon: BarChart3,
      color: "text-green-600",
    },
    {
      title: "Ventas del Día",
      value: `Bs. ${todaySales.toFixed(2)}`,
      icon: Package,
      color: "text-purple-600",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="mb-8" data-testid="admin-header">
          <h1 className="text-3xl font-bold gradient-text mb-2">
            <Settings className="inline mr-2 h-8 w-8" />
            Panel de Administración
          </h1>
          <p className="text-muted-foreground">
            Gestiona tu tienda KIVO, pedidos, fichas e inventario
          </p>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">
                      {stat.title}
                    </p>
                    <p className="text-2xl font-bold gradient-text" data-testid={`stat-${stat.title.toLowerCase().replace(/\s+/g, '-')}`}>
                      {stat.value}
                    </p>
                  </div>
                  <stat.icon className={`h-8 w-8 ${stat.color}`} />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Admin Tabs */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Gestión de la Tienda</CardTitle>
            <CardDescription>
              Administra todos los aspectos de KIVO Store desde este panel
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="pedidos" data-testid="tab-orders">
                  <ShoppingCart className="mr-2 h-4 w-4" />
                  Pedidos
                </TabsTrigger>
                <TabsTrigger value="fichas" data-testid="tab-tokens">
                  <Coins className="mr-2 h-4 w-4" />
                  Fichas
                </TabsTrigger>
                <TabsTrigger value="inventario" data-testid="tab-inventory">
                  <Package className="mr-2 h-4 w-4" />
                  Inventario
                </TabsTrigger>
                <TabsTrigger value="ajustes" data-testid="tab-settings">
                  <Settings className="mr-2 h-4 w-4" />
                  Ajustes
                </TabsTrigger>
              </TabsList>

              <TabsContent value="pedidos" className="mt-6">
                <OrdersTab />
              </TabsContent>

              <TabsContent value="fichas" className="mt-6">
                <TokensTab />
              </TabsContent>

              <TabsContent value="inventario" className="mt-6">
                <InventoryTab />
              </TabsContent>

              <TabsContent value="ajustes" className="mt-6">
                <SettingsTab />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </main>

      <Footer />
    </div>
  );
}
