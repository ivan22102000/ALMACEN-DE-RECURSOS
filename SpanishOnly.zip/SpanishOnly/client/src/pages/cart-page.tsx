import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ShoppingCart, Plus, Minus, Trash2, CreditCard, Coins, ArrowLeft } from "lucide-react";
import Header from "@/components/header";
import Footer from "@/components/footer";
import { useCart } from "@/hooks/use-cart";
import { formatCurrency } from "@/lib/format-currency";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function CartPage() {
  const { data: cartItems, updateQuantityMutation, removeItemMutation, clearCartMutation } = useCart();
  const { toast } = useToast();
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [customerInfo, setCustomerInfo] = useState({
    name: "",
    email: "",
    phone: "",
    address: {
      street: "",
      city: "",
      state: "",
      zipCode: "",
    },
    notes: "",
  });

  const subtotal = cartItems.reduce((sum, item) => 
    sum + (parseFloat(item.product.price) * item.quantity), 0
  );
  const shipping = subtotal > 200 ? 0 : 25; // Free shipping over Bs. 200
  const totalTokens = cartItems.reduce((sum, item) => 
    sum + (item.product.tokensReward * item.quantity), 0
  );
  const total = subtotal + shipping;

  const checkoutMutation = useMutation({
    mutationFn: async (orderData: any) => {
      const res = await apiRequest("POST", "/api/orders", orderData);
      return await res.json();
    },
    onSuccess: (order) => {
      toast({
        title: "¡Pedido creado exitosamente!",
        description: `Tu pedido ${order.orderCode} ha sido procesado. Recibirás tus fichas KIVO pronto.`,
      });
      clearCartMutation.mutate();
      setIsCheckingOut(false);
      setCustomerInfo({
        name: "",
        email: "",
        phone: "",
        address: { street: "", city: "", state: "", zipCode: "" },
        notes: "",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error al procesar pedido",
        description: error.message || "No se pudo crear el pedido",
        variant: "destructive",
      });
    },
  });

  const handleQuantityChange = (itemId: string, newQuantity: number) => {
    if (newQuantity < 1) return;
    updateQuantityMutation.mutate({ id: itemId, quantity: newQuantity });
  };

  const handleRemoveItem = (itemId: string) => {
    removeItemMutation.mutate(itemId);
  };

  const handleCheckout = () => {
    if (cartItems.length === 0) return;

    const orderData = {
      customerName: customerInfo.name,
      customerEmail: customerInfo.email || undefined,
      customerPhone: customerInfo.phone || undefined,
      items: cartItems.map(item => ({
        productId: item.productId,
        quantity: item.quantity,
        price: item.product.price,
      })),
      shippingAddress: customerInfo.address.street ? customerInfo.address : undefined,
      notes: customerInfo.notes || undefined,
    };

    checkoutMutation.mutate(orderData);
  };

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-16">
          <div className="text-center max-w-md mx-auto">
            <ShoppingCart className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <h1 className="text-2xl font-bold mb-2">Tu carrito está vacío</h1>
            <p className="text-muted-foreground mb-6">
              ¡Explora nuestros productos y comienza a ganar fichas KIVO!
            </p>
            <Link href="/productos">
              <Button className="gradient-bg text-white glow-effect" data-testid="button-shop-now">
                <ShoppingCart className="mr-2 h-4 w-4" />
                Ir de Compras
              </Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center mb-8">
          <Link href="/productos">
            <Button variant="ghost" size="sm" data-testid="button-back">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Seguir Comprando
            </Button>
          </Link>
        </div>

        <h1 className="text-3xl font-bold gradient-text mb-8" data-testid="page-title">
          <ShoppingCart className="inline mr-2 h-8 w-8" />
          Carrito de Compras
        </h1>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {cartItems.map((item) => (
              <Card key={item.id} className="overflow-hidden">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <img 
                      src={item.product.imageUrl || "https://via.placeholder.com/100x100?text=Sin+Imagen"}
                      alt={item.product.name}
                      className="w-20 h-20 object-cover rounded-lg"
                      data-testid={`img-cart-item-${item.id}`}
                    />
                    
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg" data-testid={`text-item-name-${item.id}`}>
                        {item.product.name}
                      </h3>
                      <p className="text-muted-foreground text-sm">
                        {formatCurrency(parseFloat(item.product.price))} c/u
                      </p>
                      <div className="flex items-center space-x-2 mt-2">
                        <div className="bitcoin-badge">
                          <Coins className="inline mr-1 h-3 w-3" />
                          +{item.product.tokensReward} fichas c/u
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                        disabled={updateQuantityMutation.isPending}
                        data-testid={`button-decrease-${item.id}`}
                      >
                        <Minus className="h-4 w-4" />
                      </Button>
                      
                      <span className="w-12 text-center font-semibold" data-testid={`text-quantity-${item.id}`}>
                        {item.quantity}
                      </span>
                      
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                        disabled={updateQuantityMutation.isPending}
                        data-testid={`button-increase-${item.id}`}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>

                    <div className="text-right">
                      <div className="font-semibold text-lg" data-testid={`text-subtotal-${item.id}`}>
                        {formatCurrency(parseFloat(item.product.price) * item.quantity)}
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRemoveItem(item.id)}
                        className="text-destructive hover:text-destructive/80 hover:bg-destructive/10"
                        disabled={removeItemMutation.isPending}
                        data-testid={`button-remove-${item.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Order Summary & Checkout */}
          <div className="space-y-6">
            {/* Order Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Resumen del Pedido</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span data-testid="text-subtotal">{formatCurrency(subtotal)}</span>
                </div>
                
                <div className="flex justify-between">
                  <span>Envío:</span>
                  <span data-testid="text-shipping">
                    {shipping === 0 ? "Gratis" : formatCurrency(shipping)}
                  </span>
                </div>
                
                {shipping === 0 && (
                  <p className="text-sm text-green-600">
                    ¡Envío gratis por compras mayores a Bs. 200!
                  </p>
                )}
                
                <Separator />
                
                <div className="flex justify-between text-lg font-bold">
                  <span>Total:</span>
                  <span className="gradient-text" data-testid="text-total">
                    {formatCurrency(total)}
                  </span>
                </div>

                <div className="bg-muted rounded-lg p-4">
                  <h4 className="font-semibold mb-2 flex items-center">
                    <Coins className="mr-2 h-4 w-4" />
                    Fichas a Ganar:
                  </h4>
                  <div className="flex items-center space-x-2">
                    <Badge className="bitcoin-badge" data-testid="badge-total-tokens">
                      +{totalTokens} Fichas
                    </Badge>
                    <span className="text-sm text-muted-foreground">
                      Con esta compra
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Checkout Form */}
            {!isCheckingOut ? (
              <Card>
                <CardContent className="p-6">
                  <Button 
                    className="w-full gradient-bg text-white glow-effect mb-4"
                    onClick={() => setIsCheckingOut(true)}
                    data-testid="button-start-checkout"
                  >
                    <CreditCard className="mr-2 h-4 w-4" />
                    Proceder al Pago
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={() => clearCartMutation.mutate()}
                    disabled={clearCartMutation.isPending}
                    data-testid="button-clear-cart"
                  >
                    Vaciar Carrito
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>Información de Entrega</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Nombre Completo *</Label>
                      <Input
                        id="name"
                        value={customerInfo.name}
                        onChange={(e) => setCustomerInfo(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="Tu nombre completo"
                        required
                        data-testid="input-customer-name"
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone">Teléfono</Label>
                      <Input
                        id="phone"
                        value={customerInfo.phone}
                        onChange={(e) => setCustomerInfo(prev => ({ ...prev, phone: e.target.value }))}
                        placeholder="70123456"
                        data-testid="input-customer-phone"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={customerInfo.email}
                      onChange={(e) => setCustomerInfo(prev => ({ ...prev, email: e.target.value }))}
                      placeholder="tu@email.com"
                      data-testid="input-customer-email"
                    />
                  </div>

                  <div>
                    <Label htmlFor="address">Dirección de Entrega</Label>
                    <Input
                      id="address"
                      value={customerInfo.address.street}
                      onChange={(e) => setCustomerInfo(prev => ({ 
                        ...prev, 
                        address: { ...prev.address, street: e.target.value }
                      }))}
                      placeholder="Calle, número, zona"
                      data-testid="input-address-street"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="city">Ciudad</Label>
                      <Input
                        id="city"
                        value={customerInfo.address.city}
                        onChange={(e) => setCustomerInfo(prev => ({ 
                          ...prev, 
                          address: { ...prev.address, city: e.target.value }
                        }))}
                        placeholder="Ciudad"
                        data-testid="input-address-city"
                      />
                    </div>
                    <div>
                      <Label htmlFor="state">Departamento</Label>
                      <Input
                        id="state"
                        value={customerInfo.address.state}
                        onChange={(e) => setCustomerInfo(prev => ({ 
                          ...prev, 
                          address: { ...prev.address, state: e.target.value }
                        }))}
                        placeholder="La Paz"
                        data-testid="input-address-state"
                      />
                    </div>
                    <div>
                      <Label htmlFor="zip">Código Postal</Label>
                      <Input
                        id="zip"
                        value={customerInfo.address.zipCode}
                        onChange={(e) => setCustomerInfo(prev => ({ 
                          ...prev, 
                          address: { ...prev.address, zipCode: e.target.value }
                        }))}
                        placeholder="0000"
                        data-testid="input-address-zip"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="notes">Notas Adicionales</Label>
                    <Textarea
                      id="notes"
                      value={customerInfo.notes}
                      onChange={(e) => setCustomerInfo(prev => ({ ...prev, notes: e.target.value }))}
                      placeholder="Instrucciones especiales de entrega..."
                      data-testid="textarea-order-notes"
                    />
                  </div>

                  <div className="flex space-x-4">
                    <Button 
                      className="flex-1 gradient-bg text-white glow-effect"
                      onClick={handleCheckout}
                      disabled={!customerInfo.name || checkoutMutation.isPending}
                      data-testid="button-confirm-order"
                    >
                      {checkoutMutation.isPending ? "Procesando..." : "Confirmar Pedido"}
                    </Button>
                    
                    <Button 
                      variant="outline"
                      onClick={() => setIsCheckingOut(false)}
                      data-testid="button-cancel-checkout"
                    >
                      Cancelar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
