import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Coins, ShoppingBag, QrCode, Store, Gift, Cog } from "lucide-react";
import Header from "@/components/header";
import Footer from "@/components/footer";
import { useProducts } from "@/hooks/use-products";
import ProductCard from "@/components/product-card";

export default function HomePage() {
  const { data: products = [], isLoading } = useProducts(4); // Get first 4 products for preview

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <section className="text-center mb-12" data-testid="hero-section">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">
            <span className="gradient-text">Bienvenido a</span>
            <span className="text-foreground ml-3">KIVO Store</span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Tu tienda online en Bolivia con sistema revolucionario de fichas de fidelidad tipo Bitcoin. 
            Compra, acumula fichas y obtén descuentos increíbles.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/productos">
              <Button className="gradient-bg text-white px-8 py-3 glow-effect scale-on-hover" data-testid="button-explore-products">
                <ShoppingBag className="mr-2 h-5 w-5" />
                Explorar Productos
              </Button>
            </Link>
            <Link href="/canjear">
              <Button variant="outline" className="border-primary text-primary hover:bg-primary hover:text-white px-8 py-3" data-testid="button-redeem-tokens">
                <QrCode className="mr-2 h-5 w-5" />
                Canjear Fichas
              </Button>
            </Link>
          </div>
        </section>

        {/* Fichas System Section */}
        <section className="mb-12" data-testid="fichas-system-section">
          <Card className="border border-border shadow-lg">
            <CardContent className="p-8">
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div>
                  <h2 className="text-3xl font-bold gradient-text mb-4">
                    <Coins className="inline mr-2 h-8 w-8" />
                    Sistema de Fichas KIVO
                  </h2>
                  <p className="text-muted-foreground mb-6">
                    Revolucionario sistema de fidelidad basado en tecnología tipo Bitcoin. 
                    Cada compra te otorga fichas digitales con códigos QR únicos.
                  </p>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 gradient-bg rounded-full flex items-center justify-center text-white font-bold">1</div>
                      <span>Realiza tu compra y recibe fichas automáticamente</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 gradient-bg rounded-full flex items-center justify-center text-white font-bold">2</div>
                      <span>Obtén códigos QR únicos para cada ficha</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 gradient-bg rounded-full flex items-center justify-center text-white font-bold">3</div>
                      <span>Canjea 5 fichas por 10% de descuento</span>
                    </div>
                  </div>
                </div>
                <div className="text-center">
                  <div className="qr-style w-48 h-48 mx-auto flex items-center justify-center mb-4">
                    <QrCode className="h-24 w-24 text-muted-foreground" />
                  </div>
                  <p className="text-sm text-muted-foreground">Ejemplo de código QR de ficha KIVO</p>
                  <div className="mt-4 text-sm">
                    <span className="font-semibold">Código:</span> 
                    <span className="font-mono ml-2">KIVO-ABC123</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Featured Products Section */}
        <section className="mb-12" data-testid="featured-products-section">
          <h2 className="text-3xl font-bold gradient-text mb-8 text-center">
            <Store className="inline mr-2 h-8 w-8" />
            Productos Destacados
          </h2>
          
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-96 bg-muted animate-pulse rounded-lg" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}

          <div className="text-center mt-8">
            <Link href="/productos">
              <Button className="gradient-bg text-white px-8 py-3 glow-effect scale-on-hover" data-testid="button-view-all-products">
                Ver Todos los Productos
              </Button>
            </Link>
          </div>
        </section>

        {/* Quick Actions Section */}
        <section className="grid md:grid-cols-3 gap-6 mb-12" data-testid="quick-actions-section">
          <Link href="/canjear">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer scale-on-hover">
              <CardContent className="p-6 text-center">
                <Gift className="h-12 w-12 mx-auto mb-4 text-primary" />
                <h3 className="text-xl font-semibold mb-2">Canjear Fichas</h3>
                <p className="text-muted-foreground">
                  Usa tus fichas acumuladas para obtener descuentos especiales
                </p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/carrito">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer scale-on-hover">
              <CardContent className="p-6 text-center">
                <ShoppingBag className="h-12 w-12 mx-auto mb-4 text-primary" />
                <h3 className="text-xl font-semibold mb-2">Mi Carrito</h3>
                <p className="text-muted-foreground">
                  Revisa y finaliza tu compra para obtener fichas
                </p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer scale-on-hover">
              <CardContent className="p-6 text-center">
                <Cog className="h-12 w-12 mx-auto mb-4 text-primary" />
                <h3 className="text-xl font-semibold mb-2">Administración</h3>
                <p className="text-muted-foreground">
                  Panel de control para gestionar la tienda
                </p>
              </CardContent>
            </Card>
          </Link>
        </section>
      </main>

      <Footer />
    </div>
  );
}
