import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Gift, QrCode, Search, CheckCircle, AlertCircle, Coins } from "lucide-react";
import Header from "@/components/header";
import Footer from "@/components/footer";
import QRScanner from "@/components/qr-scanner";
import { useAuth } from "@/hooks/use-auth";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface RedemptionResult {
  success: boolean;
  tokensRedeemed?: number;
  discountPercentage?: number;
  remainingTokens?: number;
  availableTokens?: number;
  requiredTokens?: number;
  message?: string;
}

export default function RedeemPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [orderCode, setOrderCode] = useState("");
  const [showQRScanner, setShowQRScanner] = useState(false);
  const [redemptionResult, setRedemptionResult] = useState<RedemptionResult | null>(null);

  const redeemMutation = useMutation({
    mutationFn: async (data: { orderCode: string }) => {
      const res = await apiRequest("POST", "/api/tokens/redeem", data);
      return await res.json();
    },
    onSuccess: (result: RedemptionResult) => {
      setRedemptionResult(result);
      if (result.success) {
        toast({
          title: "¡Fichas canjeadas exitosamente!",
          description: `Has canjeado ${result.tokensRedeemed} fichas por ${result.discountPercentage}% de descuento`,
        });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Error al canjear fichas",
        description: error.message || "No se pudieron canjear las fichas",
        variant: "destructive",
      });
    },
  });

  const validateQRMutation = useMutation({
    mutationFn: async (qrData: string) => {
      const res = await apiRequest("POST", "/api/tokens/validate-qr", { qrData });
      return await res.json();
    },
    onSuccess: (result) => {
      toast({
        title: "QR validado exitosamente",
        description: result.message || "Token validado y canjeado",
      });
      setShowQRScanner(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error validando QR",
        description: error.message || "No se pudo validar el código QR",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderCode.trim()) return;
    
    redeemMutation.mutate({ orderCode: orderCode.trim() });
  };

  const handleQRScan = (qrData: string) => {
    if (user?.isAdmin) {
      validateQRMutation.mutate(qrData);
    } else {
      toast({
        title: "Acceso denegado",
        description: "Solo los administradores pueden escanear códigos QR",
        variant: "destructive",
      });
      setShowQRScanner(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="text-center mb-8" data-testid="page-header">
          <h1 className="text-3xl font-bold gradient-text mb-4">
            <Gift className="inline mr-2 h-8 w-8" />
            Canjear Fichas de Fidelidad
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Usa tus fichas KIVO para obtener descuentos especiales. 
            Canjea 5 fichas y obtén 10% de descuento en tu próxima compra.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* Web Redemption */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Search className="mr-2 h-5 w-5" />
                Canje Web
              </CardTitle>
              <CardDescription>
                Ingresa tu código de compra para validar y canjear tus fichas por descuentos
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="orderCode">Código de Compra</Label>
                  <Input
                    id="orderCode"
                    value={orderCode}
                    onChange={(e) => setOrderCode(e.target.value)}
                    placeholder="KIVO-ABC123"
                    className="font-mono"
                    data-testid="input-order-code"
                  />
                </div>
                
                <Button 
                  type="submit"
                  className="w-full gradient-bg text-white glow-effect"
                  disabled={redeemMutation.isPending || !orderCode.trim()}
                  data-testid="button-redeem-tokens"
                >
                  {redeemMutation.isPending ? (
                    "Verificando..."
                  ) : (
                    <>
                      <Search className="mr-2 h-4 w-4" />
                      Verificar Fichas
                    </>
                  )}
                </Button>
              </form>

              {/* Redemption Result */}
              {redemptionResult && (
                <Alert className={redemptionResult.success ? "border-green-200 bg-green-50" : "border-yellow-200 bg-yellow-50"}>
                  <div className="flex items-start space-x-2">
                    {redemptionResult.success ? (
                      <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                    ) : (
                      <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5" />
                    )}
                    <div className="flex-1" data-testid="redemption-result">
                      {redemptionResult.success ? (
                        <div className="space-y-2">
                          <h4 className="font-semibold text-green-800">
                            ¡Fichas canjeadas exitosamente!
                          </h4>
                          <p className="text-sm text-green-700">
                            Has canjeado {redemptionResult.tokensRedeemed} fichas por {redemptionResult.discountPercentage}% de descuento.
                          </p>
                          {redemptionResult.remainingTokens !== undefined && (
                            <p className="text-sm text-green-700">
                              Te quedan {redemptionResult.remainingTokens} fichas disponibles.
                            </p>
                          )}
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <h4 className="font-semibold text-yellow-800">
                            Fichas insuficientes
                          </h4>
                          <p className="text-sm text-yellow-700">
                            {redemptionResult.message}
                          </p>
                          {redemptionResult.availableTokens !== undefined && (
                            <div className="flex items-center space-x-2 mt-2">
                              <Badge variant="outline" className="bg-white">
                                <Coins className="mr-1 h-3 w-3" />
                                {redemptionResult.availableTokens} fichas disponibles
                              </Badge>
                              <Badge variant="outline" className="bg-white">
                                {redemptionResult.requiredTokens} fichas necesarias
                              </Badge>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </Alert>
              )}
            </CardContent>
          </Card>

          {/* QR Scanner */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center">
                <QrCode className="mr-2 h-5 w-5" />
                Escáner QR
                {user?.isAdmin && (
                  <Badge variant="secondary" className="ml-2">Admin</Badge>
                )}
              </CardTitle>
              <CardDescription>
                {user?.isAdmin 
                  ? "Escanea códigos QR de fichas directamente con la cámara"
                  : "Función disponible solo para administradores"
                }
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {!showQRScanner ? (
                <div className="text-center space-y-4">
                  <div className="qr-style w-48 h-48 mx-auto flex items-center justify-center">
                    <QrCode className="h-24 w-24 text-muted-foreground" />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {user?.isAdmin 
                      ? "Cámara del dispositivo lista para escanear"
                      : "Solo administradores pueden usar esta función"
                    }
                  </p>
                  <Button 
                    className={user?.isAdmin ? "gradient-bg text-white" : ""}
                    variant={user?.isAdmin ? "default" : "outline"}
                    onClick={() => setShowQRScanner(true)}
                    disabled={!user?.isAdmin || validateQRMutation.isPending}
                    data-testid="button-start-qr-scanner"
                  >
                    <QrCode className="mr-2 h-4 w-4" />
                    {user?.isAdmin ? "Activar Escáner QR" : "Requiere Permisos de Admin"}
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <QRScanner 
                    onScan={handleQRScan}
                    onError={(error) => {
                      toast({
                        title: "Error del escáner",
                        description: error,
                        variant: "destructive",
                      });
                    }}
                  />
                  <Button 
                    variant="outline"
                    onClick={() => setShowQRScanner(false)}
                    className="w-full"
                    data-testid="button-stop-scanner"
                  >
                    Cerrar Escáner
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Information Section */}
        <Card className="mt-12 max-w-4xl mx-auto">
          <CardHeader>
            <CardTitle className="text-center">
              <Coins className="inline mr-2 h-6 w-6" />
              ¿Cómo funciona el sistema de fichas?
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6 text-center">
              <div className="space-y-2">
                <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center text-white font-bold mx-auto">
                  1
                </div>
                <h3 className="font-semibold">Compra y Gana</h3>
                <p className="text-sm text-muted-foreground">
                  Por cada compra recibes fichas KIVO automáticamente
                </p>
              </div>
              
              <div className="space-y-2">
                <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center text-white font-bold mx-auto">
                  2
                </div>
                <h3 className="font-semibold">Acumula Fichas</h3>
                <p className="text-sm text-muted-foreground">
                  Cada ficha tiene un código QR único y seguro
                </p>
              </div>
              
              <div className="space-y-2">
                <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center text-white font-bold mx-auto">
                  3
                </div>
                <h3 className="font-semibold">Canjea Descuentos</h3>
                <p className="text-sm text-muted-foreground">
                  5 fichas = 10% de descuento en tu próxima compra
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      <Footer />
    </div>
  );
}
